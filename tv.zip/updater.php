<?php
set_time_limit(300);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- CONFIGURAÇÕES ---
$repoOwner = 'ClaudioMSJ';
$repoName  = 'app_cmsj';
$branch    = 'main'; // Branch que você quer monitorar
$nomeArquivoZipRemoto = 'tv.zip'; // Nome do arquivo dentro do repositório

$arquivoZipLocal   = 'tv.zip';
$arquivoVersao     = 'versao_instalada.txt';
$diretorioDestino  = __DIR__;

// URL da API para checar o último commit
$urlApiCheck = "https://api.github.com/repos/$repoOwner/$repoName/commits/$branch";

// 1. VERIFICAR VERSÃO REMOTA (GITHUB API)
$chApi = curl_init($urlApiCheck);
curl_setopt($chApi, CURLOPT_RETURNTRANSFER, true);
curl_setopt($chApi, CURLOPT_USERAGENT, 'Monitor-Update-App-v1'); 
// Desativa verificação SSL se necessário (cuidado em produção)
curl_setopt($chApi, CURLOPT_SSL_VERIFYPEER, false); 

$respostaApi = curl_exec($chApi);
$httpCodeApi = curl_getinfo($chApi, CURLINFO_HTTP_CODE);
curl_close($chApi);

$dadosApi = json_decode($respostaApi, true);

// Verificação de segurança da API
if ($httpCodeApi != 200 || !isset($dadosApi['sha'])) {
    echo "Erro ao verificar atualizações.<br>";
    echo "HTTP Code: $httpCodeApi<br>";
    if (isset($dadosApi['message'])) {
        echo "Mensagem GitHub: " . $dadosApi['message'];
    }
    exit;
}

$novaVersao = $dadosApi['sha'];
$versaoAtual = file_exists($arquivoVersao) ? file_get_contents($arquivoVersao) : '';

// Compara as versões
if (trim($novaVersao) === trim($versaoAtual)) {
    echo "O sistema já está atualizado (Versão: " . substr($versaoAtual, 0, 7) . ").";
    exit;
}

// 2. SE TIVER ATUALIZAÇÃO, BAIXA O ARQUIVO
echo "Nova versão encontrada: " . substr($novaVersao, 0, 7) . "<br>";
echo "Iniciando atualização...<br>";

// --- CORREÇÃO DO CACHE AQUI ---
// Montamos a URL usando o SHA ($novaVersao) em vez de 'main'.
// Isso força o jsDelivr a baixar o arquivo NOVO instantaneamente.
$urlDownload = "https://cdn.jsdelivr.net/gh/$repoOwner/$repoName@$novaVersao/$nomeArquivoZipRemoto";

echo "Baixando de: $urlDownload <br>";

$fp = fopen($arquivoZipLocal, 'w+');
$ch = curl_init($urlDownload);

curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 300); // Aumentei o timeout para downloads lentos
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$exec = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);
fclose($fp);

// 3. EXTRAIR E LIMPAR
if ($exec && $httpCode == 200) {
    // Verifica se o arquivo baixado é um ZIP válido antes de tentar abrir
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $arquivoZipLocal);
    finfo_close($finfo);

    // Aceita application/zip ou application/x-zip-compressed
    if (strpos($mimeType, 'zip') !== false) {
        $zip = new ZipArchive;
        if ($zip->open($arquivoZipLocal) === TRUE) {
            $zip->extractTo($diretorioDestino);
            $zip->close();
            
            // Limpeza e Atualização do registro
            unlink($arquivoZipLocal);
            file_put_contents($arquivoVersao, $novaVersao);
            
            echo "<h3 style='color:green'>Sucesso: Sistema atualizado para versão " . substr($novaVersao, 0, 7) . "!</h3>";
            echo "Arquivos temporários removidos.";
        } else {
            echo "<h3 style='color:red'>Erro: Não foi possível abrir o arquivo ZIP.</h3>";
        }
    } else {
        echo "<h3 style='color:red'>Erro: O arquivo baixado não parece ser um ZIP válido. ($mimeType)</h3>";
        // Opcional: ver o conteúdo se for erro de texto
        // echo file_get_contents($arquivoZipLocal); 
    }
} else {
    echo "<h3 style='color:red'>Erro no download.</h3>";
    echo "Código HTTP: $httpCode <br>";
    echo "Erro Curl: $curlError";
}
?>