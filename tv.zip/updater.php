<?php
set_time_limit(300);
// Em produção, desative display_errors
ini_set('display_errors', 1); error_reporting(E_ALL);

// --- CONFIGURAÇÕES ---
$config = [
    'owner'   => 'ClaudioMSJ',
    'repo'    => 'app_cmsj',
    'branch'  => 'main',
    'file'    => 'tv.zip',
    'dirData' => 'data/'
];

// Garante diretório data
if (!is_dir($config['dirData'])) {
    mkdir($config['dirData'], 0755, true);
    file_put_contents($config['dirData'] . '.htaccess', "Deny from all");
}

$fileVersion = $config['dirData'] . 'versao_instalada.txt';
$localZip    = 'temp_update.zip';

// --- FUNÇÃO AUXILIAR (Evita repetição de cURL) ---
function request($url, $fileHandle = null) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERAGENT      => 'Updater-App-v1',
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true, // Mantenha TRUE para segurança, mude para FALSE apenas se der erro de certificado local
        CURLOPT_TIMEOUT        => 300
    ]);
    if ($fileHandle) curl_setopt($ch, CURLOPT_FILE, $fileHandle);
    
    $result = curl_exec($ch);
    $info   = curl_getinfo($ch);
    curl_close($ch);
    
    return ['body' => $result, 'code' => $info['http_code']];
}

// 1. VERIFICAR COMMIT NO GITHUB
$apiUrl = "https://api.github.com/repos/{$config['owner']}/{$config['repo']}/commits/{$config['branch']}";
$response = request($apiUrl);

if ($response['code'] !== 200) die("Erro ao verificar GitHub. HTTP: " . $response['code']);

$remoteSha = json_decode($response['body'], true)['sha'] ?? null;
$localSha  = file_exists($fileVersion) ? trim(file_get_contents($fileVersion)) : '';

if (!$remoteSha || $remoteSha === $localSha) {
    die("O sistema já está atualizado (Versão: " . substr($localSha, 0, 7) . ").");
}

// 2. BAIXAR ATUALIZAÇÃO
echo "Baixando versão " . substr($remoteSha, 0, 7) . "...<br>";
$dlUrl = "https://cdn.jsdelivr.net/gh/{$config['owner']}/{$config['repo']}@$remoteSha/{$config['file']}";

$fp = fopen($localZip, 'w+');
$dlResponse = request($dlUrl, $fp);
fclose($fp);

if ($dlResponse['code'] !== 200 || filesize($localZip) < 100) {
    unlink($localZip);
    die("<h3 style='color:red'>Erro no download (HTTP {$dlResponse['code']}).</h3>");
}

// 3. EXTRAIR
$zip = new ZipArchive;
if ($zip->open($localZip) === TRUE) {
    $zip->extractTo(__DIR__);
    $zip->close();
    
    unlink($localZip);
    file_put_contents($fileVersion, $remoteSha);
    
    echo "<h3 style='color:green'>Sucesso! Atualizado para " . substr($remoteSha, 0, 7) . ".</h3>";
} else {
    echo "<h3 style='color:red'>Erro: Arquivo ZIP corrompido ou inválido.</h3>";
}
?>