<?php
// ARQUIVO: admin.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- CONFIGURAÇÕES ---
$pastaData = 'data/';
$pastaUploads = 'uploads/';
$pastaRss = 'rss/';

// Criação de pastas e proteção
if (!is_dir($pastaData)) { mkdir($pastaData, 0777, true); file_put_contents($pastaData . '.htaccess', "Deny from all"); }
if (!is_dir($pastaRss)) { mkdir($pastaRss, 0777, true); file_put_contents($pastaRss . '.htaccess', "Deny from all"); }
if (!is_dir($pastaUploads)) { mkdir($pastaUploads, 0777, true); }

$arquivo_json = $pastaData . 'config.json';
$cacheFile    = $pastaData . 'cache_news.json';
$arquivo_lista_rss = $pastaRss . 'rss_links.txt';

$max_rss_selecao = 50; 

// --- PADRÕES RSS ---
if (!file_exists($arquivo_lista_rss)) {
    $padrao = "Notícias Gerais|https://g1.globo.com/rss/g1/\nTecnologia|https://rss.tecmundo.com.br/feed\nEsportes|https://www.espn.com.br/espn/rss/news";
    file_put_contents($arquivo_lista_rss, $padrao);
}

// Leitura do TXT RSS
$rss_sugestoes = [];
if (file_exists($arquivo_lista_rss)) {
    $linhas = file($arquivo_lista_rss, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($linhas) {
        foreach ($linhas as $linha) {
            $partes = explode('|', $linha);
            if (count($partes) >= 2) {
                $rss_sugestoes[trim($partes[0])][] = trim($partes[1]);
            }
        }
    }
}

// --- FUNÇÕES DE DADOS ---
function carregarDados($arq) { 
    return file_exists($arq) ? json_decode(file_get_contents($arq), true) ?? [] : []; 
}
function salvarDados($dados, $arq) { 
    $dados['last_update'] = time();
    // Limpa cache para forçar atualização na TV
    global $cacheFile;
    if(file_exists($cacheFile)) @unlink($cacheFile);
    return file_put_contents($arq, json_encode($dados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); 
}

// Carrega config ou cria padrão
$dadosCarregados = carregarDados($arquivo_json);
$dados = array_merge([
    'rss_sources' => [], 
    'ads' => [], 
    'titulo_tv' => "TV Corporativa", 
    'tempo_slide' => 15, 
    'max_noticias_total' => 60, 
    'frequencia_ads' => 3
], $dadosCarregados);

$mensagem = ''; $tipo_msg = '';

// --- AÇÕES ---

// 1. Resetar
if (isset($_POST['acao_resetar'])) {
    array_map('unlink', glob("$pastaUploads*"));
    if(file_exists($arquivo_json)) unlink($arquivo_json);
    if(file_exists($cacheFile)) unlink($cacheFile);
    header("Location: admin.php?msg=resetado"); exit;
}

// 2. Upload
if (isset($_FILES['novo_ad']) && $_FILES['novo_ad']['error'] === UPLOAD_ERR_OK) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($_FILES['novo_ad']['tmp_name']);
    $ext = strtolower(pathinfo($_FILES['novo_ad']['name'], PATHINFO_EXTENSION));
    
    // Lista de MIME types permitidos
    $permitidos = [
        'image/jpeg' => 'imagem', 'image/png' => 'imagem', 'image/webp' => 'imagem',
        'video/mp4' => 'video', 'video/webm' => 'video', 'video/quicktime' => 'video'
    ];

    if (array_key_exists($mime, $permitidos)) {
        $novo = uniqid('ad_') . "." . $ext;
        if (move_uploaded_file($_FILES['novo_ad']['tmp_name'], $pastaUploads . $novo)) {
            $dados['ads'][] = [
                'arquivo' => $novo, 
                'tipo' => $permitidos[$mime], 
                'duracao' => 10, 
                'ordem' => count($dados['ads']) + 1
            ];
            salvarDados($dados, $arquivo_json);
            $mensagem = "Arquivo enviado com sucesso!"; $tipo_msg = 'sucesso';
        } else {
            $mensagem = "Erro ao mover arquivo."; $tipo_msg = 'erro';
        }
    } else {
        $mensagem = "Formato não permitido ($mime). Use JPG, PNG ou MP4."; $tipo_msg = 'erro';
    }
}

// 3. Deletar
if (isset($_GET['deletar_ad'])) {
    $id = (int)$_GET['deletar_ad'];
    if (isset($dados['ads'][$id])) {
        $caminho = $pastaUploads . $dados['ads'][$id]['arquivo'];
        if (file_exists($caminho)) @unlink($caminho);
        
        array_splice($dados['ads'], $id, 1);
        salvarDados($dados, $arquivo_json);
        header("Location: admin.php"); exit;
    }
}

// 4. Salvar Geral
if (isset($_POST['salvar_geral'])) {
    // Sanitização básica
    $dados['rss_sources'] = array_slice(array_unique($_POST['rss_sources'] ?? []), 0, $max_rss_selecao);
    $dados['titulo_tv'] = strip_tags($_POST['titulo_tv'] ?? 'TV Corporativa');
    $dados['tempo_slide'] = max(5, intval($_POST['tempo_slide'] ?? 15));
    $dados['max_noticias_total'] = intval($_POST['max_noticias_total'] ?? 60);
    $dados['frequencia_ads'] = intval($_POST['frequencia_ads'] ?? 3);
    
    // Processamento dos Ads (Arrays podem vir vazios se tudo for deletado)
    $novosAds = [];
    if (isset($_POST['ad_arquivo']) && is_array($_POST['ad_arquivo'])) {
        foreach ($_POST['ad_arquivo'] as $i => $arq) {
            $novosAds[] = [
                'arquivo' => $arq, 
                'tipo' => $_POST['ad_tipo'][$i] ?? 'imagem', 
                'duracao' => intval($_POST['ad_duracao'][$i] ?? 10), 
                'ordem' => $i + 1
            ];
        }
    }
    $dados['ads'] = $novosAds;
    
    salvarDados($dados, $arquivo_json);
    $mensagem = "Configurações salvas e TV atualizada!"; $tipo_msg = 'sucesso';
}

if (isset($_GET['msg']) && $_GET['msg'] == 'resetado') {
    $mensagem = "Sistema resetado com sucesso."; $tipo_msg = 'sucesso';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin TV</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    <style>
        :root { --primary: #2563eb; --danger: #dc2626; --success: #16a34a; --bg: #f3f4f6; --card: #fff; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); margin: 0; padding: 20px; color: #1f2937; padding-bottom: 80px; }
        .container { max-width: 1000px; margin: 0 auto; }
        
        header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; background: var(--card); padding: 15px 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        h1 { margin: 0; font-size: 20px; display: flex; align-items: center; gap: 10px; }
        
        .btn { text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; font-size: 14px; border: none; cursor: pointer; color: white; background: var(--primary); display: inline-flex; align-items: center; gap: 8px; transition: 0.2s; }
        .btn:hover { opacity: 0.9; } 
        .btn-tv { background: var(--success); } 
        .btn-save { width: 100%; justify-content: center; padding: 16px; margin-top: 20px; font-size: 16px; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2); }
        .btn-del { display:block; width: 100%; background: #fee2e2; color: #dc2626; text-align: center; padding: 8px; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: bold; margin-top: 5px; border: 1px solid #fecaca; }
        .btn-del:hover { background: #fecaca; }

        .tabs { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px; }
        .tab-btn { background: #e5e7eb; border: none; padding: 10px 24px; border-radius: 20px; cursor: pointer; font-weight: 600; color: #4b5563; white-space: nowrap; }
        .tab-btn.active { background: var(--primary); color: white; }
        
        .tab-content { display: none; } 
        .tab-content.active { display: block; animation: fadeIn 0.3s; }
        
        .card { background: var(--card); padding: 25px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 20px; }
        h2 { margin-top: 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; font-size: 18px; }
        
        .form-group { margin-bottom: 15px; } 
        label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px; }
        input[type=text], input[type=number] { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; box-sizing: border-box; }
        
        .upload-area { border: 2px dashed #cbd5e1; border-radius: 12px; padding: 30px; text-align: center; cursor: pointer; background: #f8fafc; display: block; transition: 0.2s; }
        .upload-area:hover { border-color: var(--primary); background: #eff6ff; }
        
        .ads-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 15px; margin-top: 20px; }
        .ad-card { background: white; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; cursor: grab; position: relative; }
        .ad-preview { width: 100%; height: 110px; object-fit: cover; background: #000; }
        .ad-body { padding: 10px; }
        .ad-badge { position: absolute; top:5px; left:5px; background:rgba(0,0,0,0.7); color:white; font-size:10px; padding:2px 6px; border-radius:4px; font-weight:bold; }
        
        .msg { padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 600; }
        .msg.sucesso { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; } 
        .msg.erro { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        
        .rss-item { padding: 8px; border-bottom: 1px solid #f3f4f6; display: flex; align-items: center; cursor: pointer; }
        .rss-item:hover { background: #f9fafb; } .rss-item input { margin-right: 10px; transform: scale(1.2); }
        
        @keyframes fadeIn { from { opacity:0; transform: translateY(5px); } to { opacity:1; transform: translateY(0); } }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1><i class="fa-solid fa-tv"></i> Admin TV</h1>
        <a href="index.html" target="_blank" class="btn btn-tv"><i class="fa-solid fa-play"></i> Ver TV</a>
    </header>

    <?php if($mensagem): ?>
        <div class="msg <?php echo $tipo_msg; ?>"><?php echo $mensagem; ?></div>
    <?php endif; ?>

    <div class="tabs">
        <button class="tab-btn active" onclick="openTab('geral', this)">Configurações</button>
        <button class="tab-btn" onclick="openTab('noticias', this)">Notícias</button>
        <button class="tab-btn" onclick="openTab('ads', this)">Mídia & Ads</button>
        <button class="tab-btn" onclick="openTab('sistema', this)">Sistema</button>
    </div>

    <form method="POST" enctype="multipart/form-data" id="mainForm">
        <!-- GERAL -->
        <div id="geral" class="tab-content active">
            <div class="card">
                <h2>Ajustes Básicos</h2>
                <div class="form-group">
                    <label>Título da TV</label>
                    <input type="text" name="titulo_tv" value="<?php echo htmlspecialchars($dados['titulo_tv']); ?>">
                </div>
                <div style="display:flex; gap:15px">
                    <div class="form-group" style="flex:1">
                        <label>Tempo Slide Notícia (seg)</label>
                        <input type="number" name="tempo_slide" value="<?php echo $dados['tempo_slide']; ?>">
                    </div>
                    <div class="form-group" style="flex:1">
                        <label>Máx. Notícias</label>
                        <input type="number" name="max_noticias_total" value="<?php echo $dados['max_noticias_total']; ?>">
                    </div>
                </div>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Alterações</button>
        </div>

        <!-- NOTICIAS -->
        <div id="noticias" class="tab-content">
            <div class="card">
                <h2>Fontes RSS</h2>
                <p style="font-size:12px; color:#666; margin-bottom:15px">Arquivo fonte: <b>rss/rss_links.txt</b></p>
                <?php 
                if(!empty($rss_sugestoes)) {
                    foreach($rss_sugestoes as $cat => $links) {
                        echo "<h4 style='color:var(--primary); margin:15px 0 5px 0'>$cat</h4>";
                        foreach($links as $link) {
                            $checked = in_array($link, $dados['rss_sources']) ? 'checked' : '';
                            echo "<label class='rss-item'><input type='checkbox' name='rss_sources[]' value='$link' $checked> <span style='font-size:13px; word-break:break-all'>$link</span></label>";
                        }
                    }
                } else {
                    echo "<p>Nenhuma fonte RSS encontrada.</p>";
                }
                ?>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Fontes</button>
        </div>

        <!-- ADS -->
        <div id="ads" class="tab-content">
            <div class="card">
                <h2>Gerenciar Mídia</h2>
                <div class="form-group" style="max-width:300px">
                    <label>Frequência (1 anúncio a cada X notícias)</label>
                    <input type="number" name="frequencia_ads" value="<?php echo $dados['frequencia_ads']; ?>">
                </div>

                <label class="upload-area">
                    <input type="file" name="novo_ad" style="display:none" onchange="this.form.submit()">
                    <i class="fa-solid fa-cloud-arrow-up" style="font-size:32px; color:#9ca3af; margin-bottom:10px"></i><br>
                    <strong>Clique para enviar Imagem ou Vídeo</strong>
                </label>

                <div class="ads-grid" id="lista-ads">
                    <?php if(!empty($dados['ads'])): foreach($dados['ads'] as $idx => $ad): ?>
                    <div class="ad-card">
                        <span class="ad-badge"><?php echo strtoupper($ad['tipo']); ?></span>
                        <input type="hidden" name="ad_arquivo[]" value="<?php echo $ad['arquivo']; ?>">
                        <input type="hidden" name="ad_tipo[]" value="<?php echo $ad['tipo']; ?>">
                        
                        <?php if($ad['tipo']=='video'): ?>
                            <video src="<?php echo $pastaUploads.$ad['arquivo']; ?>" class="ad-preview"></video>
                            <input type="hidden" name="ad_duracao[]" value="0">
                        <?php else: ?>
                            <img src="<?php echo $pastaUploads.$ad['arquivo']; ?>" class="ad-preview">
                        <?php endif; ?>

                        <div class="ad-body">
                            <?php if($ad['tipo']!='video'): ?>
                                <label style="font-size:10px">Duração (s)</label>
                                <!-- Campo clicável para edição -->
                                <input type="number" name="ad_duracao[]" value="<?php echo $ad['duracao']; ?>" style="padding:5px">
                            <?php else: ?>
                                <span style="font-size:11px; color:#666; display:block; padding:8px 0; font-style:italic">Tempo do Vídeo</span>
                            <?php endif; ?>
                            
                            <!-- Botão Delete funcional (Link) -->
                            <a href="?deletar_ad=<?php echo $idx; ?>" class="btn-del" onclick="return confirm('Tem certeza que deseja apagar?');">
                                <i class="fa-solid fa-trash"></i> Excluir
                            </a>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Ordem</button>
        </div>
    </form>

    <!-- SISTEMA -->
    <div id="sistema" class="tab-content">
        <div class="card" style="border:1px solid #fee2e2">
            <h2 style="color:var(--danger)">Zona de Perigo</h2>
            <p>Esta ação irá apagar todas as configurações e arquivos enviados.</p>
            <form method="POST">
                <input type="hidden" name="acao_resetar" value="1">
                <button type="submit" class="btn" style="background:var(--danger); width:100%" onclick="return confirm('Confirma a formatação do sistema?')">FORMATAR TUDO</button>
            </form>
        </div>
    </div>
</div>

<script>
    function openTab(id, btn) {
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.getElementById(id).classList.add('active');
        if(btn) btn.classList.add('active');
        localStorage.setItem('activeTab', id);
    }
    
    document.addEventListener("DOMContentLoaded", () => {
        const t = localStorage.getItem('activeTab') || 'geral';
        const b = document.querySelector(`button[onclick*="'${t}'"]`);
        if(b) openTab(t, b);
        
        // CORREÇÃO CRÍTICA DO SORTABLE:
        // filter: define elementos que NÃO iniciam o arrastar
        // preventOnFilter: false PERMITE clicar nesses elementos
        var el = document.getElementById('lista-ads');
        if(el) {
            new Sortable(el, { 
                animation: 150,
                filter: 'input, .btn-del', 
                preventOnFilter: false
            });
        }
    });
</script>
</body>
</html>