<?php
// --- CONFIGURAÇÕES DO SISTEMA ---
$arquivo_json = 'config.json';
$pasta_uploads = 'uploads/';
$max_rss_selecao = 5;

// --- LÓGICA DO SISTEMA ---
$mensagem = '';
$tipo_msg = '';

// PRESETS RSS (Sugestões)
$rss_sugestoes = [
    'Notícias Gerais' => [
        'https://g1.globo.com/rss/g1/brasil/',
        'http://rss.uol.com.br/feed/noticias.xml',
        'https://www.cnnbrasil.com.br/feed/',
        'https://feeds.bbci.co.uk/portuguese/rss.xml'
    ],
    'Economia' => [
        'https://www.infomoney.com.br/feed/',
        'https://g1.globo.com/rss/g1/economia/'
    ],
    'Tecnologia' => [
        'https://rss.tecmundo.com.br/feed',
        'https://olhardigital.com.br/rss',
        'https://canaltech.com.br/rss/'
    ],
    'Esportes' => [
        'https://www.espn.com.br/espn/rss/news',
        'https://ge.globo.com/rss/ge/'
    ]
];

// Cria pasta se não existir
if (!is_dir($pasta_uploads)) mkdir($pasta_uploads, 0777, true);

// Funções Auxiliares
function carregarDados($arquivo) {
    return file_exists($arquivo) ? json_decode(file_get_contents($arquivo), true) ?? [] : [];
}

function salvarDados($dados, $arquivo) {
    $dados['last_update'] = time();
    return file_put_contents($arquivo, json_encode($dados, JSON_PRETTY_PRINT));
}

// Carrega config inicial
$dados = carregarDados($arquivo_json);
// Defaults (caso o arquivo não exista ou esteja vazio)
$dados = array_merge([
    'rss_sources' => [],
    'ads' => [],
    'titulo_tv' => "TV Corporativa",
    'tempo_slide' => 15,
    'max_noticias_total' => 20,
    'frequencia_ads' => 2
], $dados);

// --- PROCESSAMENTO DE FORMULÁRIOS ---

// 1. Resetar Sistema
if (isset($_POST['acao_resetar'])) {
    array_map('unlink', glob("$pasta_uploads*")); // Limpa pasta de uploads
    if(file_exists($arquivo_json)) unlink($arquivo_json); // Limpa json
    header("Location: admin.php?msg=resetado"); exit;
}

// 2. Upload de AD (Imagem ou Vídeo)
if (isset($_FILES['novo_ad'])) {
    if ($_FILES['novo_ad']['error'] === UPLOAD_ERR_OK) {
        // Validação de segurança MIME TYPE
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($_FILES['novo_ad']['tmp_name']);
        $ext = strtolower(pathinfo($_FILES['novo_ad']['name'], PATHINFO_EXTENSION));
        
        $permitidos = [
            'image/jpeg' => 'imagem', 
            'image/png' => 'imagem', 
            'video/mp4' => 'video'
        ];

        if (array_key_exists($mime, $permitidos)) {
            $novoNome = uniqid('ad_') . "." . $ext;
            if (move_uploaded_file($_FILES['novo_ad']['tmp_name'], $pasta_uploads . $novoNome)) {
                $dados['ads'][] = [
                    'arquivo' => $novoNome,
                    'tipo' => $permitidos[$mime],
                    'duracao' => 10,
                    'ordem' => count($dados['ads']) + 1
                ];
                salvarDados($dados, $arquivo_json);
                $mensagem = "Arquivo enviado com sucesso!"; $tipo_msg = 'sucesso';
            }
        } else {
            $mensagem = "Formato inválido (apenas JPG, PNG ou MP4)."; $tipo_msg = 'erro';
        }
    }
}

// 3. Deletar AD
if (isset($_GET['deletar_ad'])) {
    $id = (int)$_GET['deletar_ad'];
    if (isset($dados['ads'][$id])) {
        @unlink($pasta_uploads . $dados['ads'][$id]['arquivo']);
        array_splice($dados['ads'], $id, 1); // Reindexa array
        salvarDados($dados, $arquivo_json);
        header("Location: admin.php"); exit;
    }
}

// 4. Salvar Configurações Gerais
if (isset($_POST['salvar_geral'])) {
    // RSS
    $feeds = isset($_POST['rss_sources']) ? $_POST['rss_sources'] : [];
    $dados['rss_sources'] = array_slice(array_unique($feeds), 0, $max_rss_selecao);
    
    // Configs Gerais
    $dados['titulo_tv'] = filter_input(INPUT_POST, 'titulo_tv', FILTER_SANITIZE_SPECIAL_CHARS);
    $dados['tempo_slide'] = (int)$_POST['tempo_slide'];
    $dados['max_noticias_total'] = (int)$_POST['max_noticias_total'];
    $dados['frequencia_ads'] = (int)$_POST['frequencia_ads'];

    // Reordenação e Edição de Ads
    if (isset($_POST['ad_arquivo'])) {
        $novosAds = [];
        foreach ($_POST['ad_arquivo'] as $idx => $arq) {
            $novosAds[] = [
                'arquivo' => $arq,
                'tipo' => $_POST['ad_tipo'][$idx],
                'duracao' => (int)$_POST['ad_duracao'][$idx],
                'ordem' => $idx + 1
            ];
        }
        $dados['ads'] = $novosAds;
    } else {
        $dados['ads'] = []; // Caso delete todos via JS e salve
    }

    salvarDados($dados, $arquivo_json);
    $mensagem = "Configurações salvas!"; $tipo_msg = 'sucesso';
}

if (isset($_GET['msg']) && $_GET['msg'] == 'resetado') {
    $mensagem = "Sistema resetado para os padrões de fábrica."; $tipo_msg = 'sucesso';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin TV</title>
    <!-- Ícones e Sortable -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    
    <style>
        :root { --primary: #2563eb; --danger: #dc2626; --success: #16a34a; --bg: #f3f4f6; --card: #ffffff; }
        * { box-sizing: border-box; outline: none; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); margin: 0; padding: 20px; color: #1f2937; padding-bottom: 80px; }
        
        .container { max-width: 1000px; margin: 0 auto; }
        
        /* Header */
        header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; background: var(--card); padding: 15px 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        h1 { margin: 0; font-size: 20px; display: flex; align-items: center; gap: 10px; }
        .actions { display: flex; gap: 10px; }
        .btn { text-decoration: none; padding: 8px 16px; border-radius: 6px; font-weight: 600; font-size: 14px; transition: 0.2s; border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; }
        .btn-tv { background: var(--success); color: white; }
        .btn-save { background: var(--primary); color: white; width: 100%; justify-content: center; padding: 14px; font-size: 16px; margin-top: 20px; }
        
        /* Tabs */
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px; }
        .tab-btn { background: #e5e7eb; border: none; padding: 10px 20px; border-radius: 20px; cursor: pointer; color: #4b5563; font-weight: 600; white-space: nowrap; transition: 0.2s; }
        .tab-btn.active { background: var(--primary); color: white; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.3); }
        .tab-content { display: none; animation: fadeIn 0.3s; }
        .tab-content.active { display: block; }
        
        /* Cards */
        .card { background: var(--card); padding: 25px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 20px; }
        h2 { margin-top: 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; font-size: 18px; color: #111827; }
        h3 { color: var(--primary); font-size: 15px; margin: 15px 0 10px 0; }

        /* Forms */
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 14px; color: #374151; }
        input[type=text], input[type=number] { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; transition: 0.2s; }
        input:focus { border-color: var(--primary); ring: 2px solid var(--primary); }
        .row { display: flex; gap: 15px; }
        .col { flex: 1; }

        /* Upload Area */
        .upload-area { border: 2px dashed #cbd5e1; border-radius: 8px; padding: 30px; text-align: center; cursor: pointer; transition: 0.2s; background: #f8fafc; }
        .upload-area:hover { border-color: var(--primary); background: #eff6ff; }
        .upload-icon { font-size: 32px; color: #94a3b8; margin-bottom: 10px; }

        /* Ads Grid */
        .ads-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; margin-top: 20px; }
        .ad-card { background: white; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; position: relative; cursor: move; transition: transform 0.2s; }
        .ad-card:active { transform: scale(0.98); }
        .ad-preview { width: 100%; height: 100px; object-fit: cover; background: #000; }
        .ad-body { padding: 10px; }
        .badge { font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: bold; position: absolute; top: 5px; left: 5px; background: rgba(0,0,0,0.6); color: white; }
        .btn-del { width: 100%; background: #fee2e2; color: var(--danger); border: none; padding: 6px; border-radius: 4px; cursor: pointer; font-size: 12px; margin-top: 5px; }
        
        /* RSS */
        .rss-counter { background: #eff6ff; color: var(--primary); padding: 10px 15px; border-radius: 6px; display: flex; justify-content: space-between; font-weight: bold; font-size: 14px; margin-bottom: 15px; }
        .rss-item { display: flex; align-items: center; padding: 10px; border-bottom: 1px solid #f3f4f6; transition: 0.1s; }
        .rss-item:hover { background: #f9fafb; }
        .rss-item input { width: 18px; height: 18px; margin-right: 12px; cursor: pointer; }
        .rss-link { font-size: 13px; color: #4b5563; word-break: break-all; }

        /* Alerts */
        .msg { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: 500; text-align: center; }
        .msg.sucesso { background: #dcfce7; color: #166534; }
        .msg.erro { background: #fee2e2; color: #991b1b; }

        @keyframes fadeIn { from { opacity:0; transform: translateY(5px); } to { opacity:1; transform: translateY(0); } }
        
        @media(max-width: 600px) {
            .row { flex-direction: column; gap: 0; }
            header { flex-direction: column; gap: 15px; text-align: center; }
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1><i class="fa-solid fa-tv"></i> Admin TV</h1>
        <div class="actions">
            <a href="index.php" target="_blank" class="btn btn-tv"><i class="fa-solid fa-external-link-alt"></i> Ver TV</a>
        </div>
    </header>

    <?php if($mensagem): ?>
        <div class="msg <?php echo $tipo_msg; ?>"><?php echo $mensagem; ?></div>
    <?php endif; ?>

    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab('geral', this)">Configurações</button>
        <button class="tab-btn" onclick="switchTab('noticias', this)">Notícias</button>
        <button class="tab-btn" onclick="switchTab('ads', this)">Mídia & Ads</button>
        <button class="tab-btn" onclick="switchTab('sistema', this)">Sistema</button>
    </div>

    <form method="POST" enctype="multipart/form-data">
        
        <!-- ABA GERAL -->
        <div id="geral" class="tab-content active">
            <div class="card">
                <h2><i class="fa-solid fa-sliders"></i> Ajustes Gerais</h2>
                
                <div class="form-group">
                    <label>Título da TV</label>
                    <input type="text" name="titulo_tv" value="<?php echo htmlspecialchars($dados['titulo_tv']); ?>">
                </div>

                <div class="row">
                    <div class="col form-group">
                        <label>Tempo por Slide (seg)</label>
                        <input type="number" name="tempo_slide" value="<?php echo $dados['tempo_slide']; ?>">
                    </div>
                    <div class="col form-group">
                        <label>Máx. Notícias</label>
                        <input type="number" name="max_noticias_total" value="<?php echo $dados['max_noticias_total']; ?>">
                    </div>
                </div>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Tudo</button>
        </div>

        <!-- ABA NOTICIAS -->
        <div id="noticias" class="tab-content">
            <div class="card">
                <h2><i class="fa-solid fa-newspaper"></i> Fontes de Notícias</h2>
                <div class="rss-counter">
                    <span>Fontes selecionadas:</span>
                    <span id="rss-count">0 / <?php echo $max_rss_selecao; ?></span>
                </div>

                <?php foreach($rss_sugestoes as $cat => $links): ?>
                    <h3><?php echo $cat; ?></h3>
                    <div style="border:1px solid #e5e7eb; border-radius:8px; overflow:hidden;">
                    <?php foreach($links as $link): 
                        $checked = in_array($link, $dados['rss_sources']) ? 'checked' : '';
                    ?>
                        <label class="rss-item">
                            <input type="checkbox" name="rss_sources[]" class="chk-rss" value="<?php echo $link; ?>" <?php echo $checked; ?>>
                            <span class="rss-link"><?php echo $link; ?></span>
                        </label>
                    <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Seleção</button>
        </div>

        <!-- ABA ADS -->
        <div id="ads" class="tab-content">
            <div class="card">
                <h2><i class="fa-solid fa-bullhorn"></i> Gestão de Anúncios</h2>
                
                <div class="form-group" style="max-width:300px; margin-bottom:20px;">
                    <label>Frequência (Exibir Ad a cada X notícias)</label>
                    <input type="number" name="frequencia_ads" value="<?php echo $dados['frequencia_ads']; ?>">
                </div>

                <!-- Upload Area -->
                <label class="upload-area">
                    <input type="file" name="novo_ad" style="display:none" onchange="this.form.submit()">
                    <div class="upload-icon"><i class="fa-solid fa-cloud-arrow-up"></i></div>
                    <strong>Clique ou Arraste arquivos aqui</strong><br>
                    <span style="font-size:12px; color:#64748b;">Suporta JPG, PNG ou MP4</span>
                </label>

                <div class="ads-grid" id="lista-ads">
                    <?php foreach($dados['ads'] as $idx => $ad): ?>
                    <div class="ad-card">
                        <span class="badge"><?php echo strtoupper($ad['tipo']); ?></span>
                        <input type="hidden" name="ad_arquivo[]" value="<?php echo $ad['arquivo']; ?>">
                        <input type="hidden" name="ad_tipo[]" value="<?php echo $ad['tipo']; ?>">
                        
                        <?php if($ad['tipo'] == 'video'): ?>
                            <video src="<?php echo $pasta_uploads . $ad['arquivo']; ?>" class="ad-preview"></video>
                            <input type="hidden" name="ad_duracao[]" value="0">
                        <?php else: ?>
                            <img src="<?php echo $pasta_uploads . $ad['arquivo']; ?>" class="ad-preview">
                        <?php endif; ?>

                        <div class="ad-body">
                            <?php if($ad['tipo'] != 'video'): ?>
                            <label style="font-size:11px;">Duração (s)</