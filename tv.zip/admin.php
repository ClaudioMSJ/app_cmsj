<?php
// ARQUIVO: admin.php
session_start();

// --- CONFIGURAÇÕES ---
$pastaData = 'data/';
$pastaUploads = 'uploads/';
$pastaRss = 'rss/';

// Cria pastas se não existirem
if (!is_dir($pastaData)) { mkdir($pastaData, 0777, true); file_put_contents($pastaData . '.htaccess', "Deny from all"); }
if (!is_dir($pastaRss)) { mkdir($pastaRss, 0777, true); file_put_contents($pastaRss . '.htaccess', "Deny from all"); }
if (!is_dir($pastaUploads)) { mkdir($pastaUploads, 0777, true); }

$arquivo_json = $pastaData . 'config.json';
$cacheFile    = $pastaData . 'cache_news.json';
$arquivo_lista_rss = $pastaRss . 'rss_links.txt';

$max_rss_selecao = 50; 

// --- GERENCIAMENTO DE RSS (TXT) ---
if (!file_exists($arquivo_lista_rss)) {
    // Lista padrão inicial
    $padrao = "Notícias Gerais|https://g1.globo.com/rss/g1/\nTecnologia|https://rss.tecmundo.com.br/feed\nEsportes|https://www.espn.com.br/espn/rss/news";
    file_put_contents($arquivo_lista_rss, $padrao);
}

$rss_sugestoes = [];
if (file_exists($arquivo_lista_rss)) {
    $linhas = file($arquivo_lista_rss, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($linhas as $linha) {
        $partes = explode('|', $linha);
        if (count($partes) >= 2) {
            $rss_sugestoes[trim($partes[0])][] = trim($partes[1]);
        }
    }
}

// --- FUNÇÕES ---
function carregarDados($arq) { 
    return file_exists($arq) ? json_decode(file_get_contents($arq), true) ?? [] : []; 
}
function salvarDados($dados, $arq) { 
    $dados['last_update'] = time();
    // Limpa cache de notícias ao salvar configurações para forçar atualização
    global $cacheFile;
    if(file_exists($cacheFile)) @unlink($cacheFile);
    return file_put_contents($arq, json_encode($dados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); 
}

$dados = array_merge([
    'rss_sources' => [], 'ads' => [], 'titulo_tv' => "TV Corporativa", 
    'tempo_slide' => 15, 'max_noticias_total' => 60, 'frequencia_ads' => 3
], carregarDados($arquivo_json));

$mensagem = ''; $tipo_msg = '';

// --- PROCESSAMENTO ---
if (isset($_POST['acao_resetar'])) {
    array_map('unlink', glob("$pastaUploads*"));
    if(file_exists($arquivo_json)) unlink($arquivo_json);
    if(file_exists($cacheFile)) unlink($cacheFile);
    header("Location: admin.php?msg=resetado"); exit;
}

if (isset($_FILES['novo_ad']) && $_FILES['novo_ad']['error'] === UPLOAD_ERR_OK) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($_FILES['novo_ad']['tmp_name']);
    $ext = strtolower(pathinfo($_FILES['novo_ad']['name'], PATHINFO_EXTENSION));
    $permitidos = ['image/jpeg'=>'imagem', 'image/png'=>'imagem', 'image/webp'=>'imagem', 'video/mp4'=>'video', 'video/webm'=>'video'];

    if (array_key_exists($mime, $permitidos)) {
        $novo = uniqid('ad_') . "." . $ext;
        if (move_uploaded_file($_FILES['novo_ad']['tmp_name'], $pastaUploads . $novo)) {
            $dados['ads'][] = ['arquivo'=>$novo, 'tipo'=>$permitidos[$mime], 'duracao'=>10, 'ordem'=>count($dados['ads'])+1];
            salvarDados($dados, $arquivo_json);
            $mensagem = "Arquivo enviado com sucesso!"; $tipo_msg = 'sucesso';
        }
    } else {
        $mensagem = "Formato inválido ($mime). Use JPG, PNG ou MP4."; $tipo_msg = 'erro';
    }
}

if (isset($_GET['deletar_ad'])) {
    $id = (int)$_GET['deletar_ad'];
    if (isset($dados['ads'][$id])) {
        @unlink($pastaUploads . $dados['ads'][$id]['arquivo']);
        array_splice($dados['ads'], $id, 1);
        salvarDados($dados, $arquivo_json);
        header("Location: admin.php"); exit;
    }
}

if (isset($_POST['salvar_geral'])) {
    $dados['rss_sources'] = array_slice(array_unique($_POST['rss_sources'] ?? []), 0, $max_rss_selecao);
    $dados['titulo_tv'] = filter_input(INPUT_POST, 'titulo_tv', FILTER_SANITIZE_SPECIAL_CHARS);
    $dados['tempo_slide'] = (int)$_POST['tempo_slide'];
    $dados['max_noticias_total'] = (int)$_POST['max_noticias_total'];
    $dados['frequencia_ads'] = (int)$_POST['frequencia_ads'];
    
    if (isset($_POST['ad_arquivo'])) {
        $novos = [];
        foreach ($_POST['ad_arquivo'] as $i => $arq) {
            $novos[] = [
                'arquivo' => $arq, 
                'tipo' => $_POST['ad_tipo'][$i], 
                'duracao' => (int)$_POST['ad_duracao'][$i], 
                'ordem' => $i + 1
            ];
        }
        $dados['ads'] = $novos;
    } else { $dados['ads'] = []; }
    
    salvarDados($dados, $arquivo_json);
    $mensagem = "Configurações atualizadas e TV notificada!"; $tipo_msg = 'sucesso';
}

if (isset($_GET['msg']) && $_GET['msg'] == 'resetado') {
    $mensagem = "Sistema limpo com sucesso."; $tipo_msg = 'sucesso';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel TV Corporativa</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    <style>
        :root { --primary: #2563eb; --danger: #dc2626; --success: #16a34a; --bg: #f3f4f6; --card: #fff; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding: 20px; color: #1f2937; padding-bottom: 80px; }
        .container { max-width: 1000px; margin: 0 auto; }
        header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; background: var(--card); padding: 15px 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        h1 { margin: 0; font-size: 20px; display: flex; align-items: center; gap: 10px; }
        .btn { text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; font-size: 14px; border: none; cursor: pointer; color: white; background: var(--primary); display: inline-flex; align-items: center; gap: 8px; transition: 0.2s; }
        .btn:hover { opacity: 0.9; } .btn-tv { background: var(--success); } .btn-save { width: 100%; justify-content: center; padding: 15px; margin-top: 20px; font-size: 16px; }
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px; }
        .tab-btn { background: #e5e7eb; border: none; padding: 10px 20px; border-radius: 20px; cursor: pointer; font-weight: 600; color: #4b5563; white-space: nowrap; }
        .tab-btn.active { background: var(--primary); color: white; }
        .tab-content { display: none; } .tab-content.active { display: block; animation: fadeIn 0.3s; }
        .card { background: var(--card); padding: 25px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 20px; }
        h2 { margin-top: 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; font-size: 18px; }
        .form-group { margin-bottom: 15px; } label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px; }
        input[type=text], input[type=number] { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; box-sizing: border-box; }
        .upload-area { border: 2px dashed #cbd5e1; border-radius: 12px; padding: 30px; text-align: center; cursor: pointer; background: #f8fafc; display: block; transition: 0.2s; }
        .upload-area:hover { border-color: var(--primary); background: #eff6ff; }
        .ads-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; margin-top: 20px; }
        .ad-card { background: white; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; cursor: grab; position: relative; }
        .ad-preview { width: 100%; height: 100px; object-fit: cover; background: #000; }
        .ad-body { padding: 10px; }
        .msg { padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 600; }
        .msg.sucesso { background: #dcfce7; color: #166534; } .msg.erro { background: #fee2e2; color: #991b1b; }
        .rss-item { padding: 8px; border-bottom: 1px solid #f3f4f6; display: flex; align-items: center; cursor: pointer; }
        .rss-item:hover { background: #f9fafb; } .rss-item input { margin-right: 10px; transform: scale(1.2); }
        @keyframes fadeIn { from { opacity:0; transform: translateY(5px); } to { opacity:1; transform: translateY(0); } }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1><i class="fa-solid fa-tv"></i> Admin TV</h1>
        <a href="index.html" target="_blank" class="btn btn-tv"><i class="fa-solid fa-play"></i> Abrir TV</a>
    </header>

    <?php if($mensagem): ?>
        <div class="msg <?php echo $tipo_msg; ?>"><?php echo $mensagem; ?></div>
    <?php endif; ?>

    <div class="tabs">
        <button class="tab-btn active" onclick="openTab('geral', this)">Configurações</button>
        <button class="tab-btn" onclick="openTab('noticias', this)">Fontes de Notícias</button>
        <button class="tab-btn" onclick="openTab('ads', this)">Mídia & Anúncios</button>
        <button class="tab-btn" onclick="openTab('sistema', this)">Sistema</button>
    </div>

    <form method="POST" enctype="multipart/form-data" id="mainForm">
        <!-- GERAL -->
        <div id="geral" class="tab-content active">
            <div class="card">
                <h2>Básico</h2>
                <div class="form-group">
                    <label>Nome da TV</label>
                    <input type="text" name="titulo_tv" value="<?php echo htmlspecialchars($dados['titulo_tv']); ?>">
                </div>
                <div style="display:flex; gap:15px">
                    <div class="form-group" style="flex:1">
                        <label>Tempo Slide Notícia (seg)</label>
                        <input type="number" name="tempo_slide" value="<?php echo $dados['tempo_slide']; ?>">
                    </div>
                    <div class="form-group" style="flex:1">
                        <label>Máx. Notícias no Loop</label>
                        <input type="number" name="max_noticias_total" value="<?php echo $dados['max_noticias_total']; ?>">
                    </div>
                </div>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Tudo</button>
        </div>

        <!-- NOTÍCIAS -->
        <div id="noticias" class="tab-content">
            <div class="card">
                <h2>Selecione as Fontes RSS</h2>
                <p style="font-size:12px; color:#666; margin-bottom:15px">Edite o arquivo <b>rss/rss_links.txt</b> para adicionar mais fontes.</p>
                <?php 
                if(!empty($rss_sugestoes)) {
                    foreach($rss_sugestoes as $cat => $links) {
                        echo "<h4 style='color:var(--primary); margin:15px 0 5px 0'>$cat</h4>";
                        foreach($links as $link) {
                            $checked = in_array($link, $dados['rss_sources']) ? 'checked' : '';
                            echo "<label class='rss-item'><input type='checkbox' name='rss_sources[]' value='$link' $checked> <span style='font-size:13px; word-break:break-all'>$link</span></label>";
                        }
                    }
                } else {
                    echo "<p>Nenhuma fonte encontrada no arquivo rss_links.txt</p>";
                }
                ?>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Seleção</button>
        </div>

        <!-- ADS -->
        <div id="ads" class="tab-content">
            <div class="card">
                <h2>Gerenciador de Arquivos</h2>
                <div class="form-group" style="max-width:300px">
                    <label>Frequência (Mostrar 1 Mídia a cada X notícias)</label>
                    <input type="number" name="frequencia_ads" value="<?php echo $dados['frequencia_ads']; ?>">
                </div>
                <label class="upload-area">
                    <input type="file" name="novo_ad" style="display:none" onchange="this.form.submit()">
                    <i class="fa-solid fa-cloud-arrow-up" style="font-size:30px; color:#9ca3af; margin-bottom:10px"></i><br>
                    Clique para enviar Imagem ou Vídeo
                </label>
                <div class="ads-grid" id="lista-ads">
                    <?php foreach($dados['ads'] as $idx => $ad): ?>
                    <div class="ad-card">
                        <input type="hidden" name="ad_arquivo[]" value="<?php echo $ad['arquivo']; ?>">
                        <input type="hidden" name="ad_tipo[]" value="<?php echo $ad['tipo']; ?>">
                        <?php if($ad['tipo']=='video'): ?>
                            <video src="<?php echo $pastaUploads.$ad['arquivo']; ?>" class="ad-preview"></video>
                            <input type="hidden" name="ad_duracao[]" value="0">
                        <?php else: ?>
                            <img src="<?php echo $pastaUploads.$ad['arquivo']; ?>" class="ad-preview">
                        <?php endif; ?>
                        <div class="ad-body">
                            <?php if($ad['tipo']!='video'): ?>
                                <label style="font-size:10px">Duração (s)</label>
                                <input type="number" name="ad_duracao[]" value="<?php echo $ad['duracao']; ?>" style="padding:5px">
                            <?php else: ?>
                                <span style="font-size:11px; color:#666; display:block; padding:8px 0">Tempo do Vídeo</span>
                            <?php endif; ?>
                            <button type="button" class="btn" style="background:#fee2e2; color:#dc2626; width:100%; margin-top:5px; padding:5px; font-size:12px" onclick="if(confirm('Excluir?')) location.href='?deletar_ad=<?php echo $idx; ?>'">Excluir</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Ordem</button>
        </div>
    </form>

    <!-- SISTEMA -->
    <div id="sistema" class="tab-content">
        <div class="card" style="border:1px solid #fee2e2">
            <h2 style="color:var(--danger)">Zona de Perigo</h2>
            <p>Isso apagará todas as configurações e arquivos enviados (Ads).</p>
            <form method="POST">
                <input type="hidden" name="acao_resetar" value="1">
                <button type="submit" class="btn" style="background:var(--danger)" onclick="return confirm('Tem certeza absoluta?')">FORMATAR SISTEMA</button>
            </form>
        </div>
    </div>
</div>

<script>
    function openTab(id, btn) {
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.getElementById(id).classList.add('active');
        if(btn) btn.classList.add('active');
        localStorage.setItem('activeTab', id);
    }
    document.addEventListener("DOMContentLoaded", () => {
        const t = localStorage.getItem('activeTab') || 'geral';
        const b = document.querySelector(`button[onclick*="'${t}'"]`);
        if(b) openTab(t, b);
        new Sortable(document.getElementById('lista-ads'), { animation: 150 });
    });
</script>
</body>
</html>