<?php
// ARQUIVO: admin.php

// --- CONFIGURAÇÕES DE PASTAS ---
$pastaData = 'data/';
$pastaUploads = 'uploads/';
$pastaRss = 'rss/'; // PASTA CORRETA

// Cria pastas necessárias e protege
if (!is_dir($pastaData)) {
    mkdir($pastaData, 0777, true);
    file_put_contents($pastaData . '.htaccess', "Deny from all");
}
if (!is_dir($pastaRss)) {
    mkdir($pastaRss, 0777, true);
    file_put_contents($pastaRss . '.htaccess', "Deny from all");
}
if (!is_dir($pastaUploads)) {
    mkdir($pastaUploads, 0777, true);
}

// Arquivos
$arquivo_json = $pastaData . 'config.json';
$cacheFile    = $pastaData . 'cache_news.json';
$arquivo_lista_rss = $pastaRss . 'rss_links.txt'; // CAMINHO CORRIGIDO

// LIMITE DE FONTES
$max_rss_selecao = 50; 

// --- LÓGICA DE RSS (TXT) ---
// Se não existir, cria com o padrão
if (!file_exists($arquivo_lista_rss)) {
    $conteudoPadrao = "Notícias Gerais|https://g1.globo.com/rss/g1/";
    file_put_contents($arquivo_lista_rss, $conteudoPadrao);
}

// Lê o arquivo TXT
$rss_sugestoes = [];
// Verifica se o arquivo tem conteúdo antes de ler
if (file_exists($arquivo_lista_rss)) {
    $linhas = file($arquivo_lista_rss, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($linhas) {
        foreach ($linhas as $linha) {
            $partes = explode('|', $linha);
            // Garante que tem Categoria E Link
            if (count($partes) >= 2) {
                $categoria = trim($partes[0]);
                $link = trim($partes[1]);
                // Validação básica para não incluir linhas vazias
                if (!empty($link)) {
                    $rss_sugestoes[$categoria][] = $link;
                }
            }
        }
    }
}

// --- FUNÇÕES AUXILIARES ---
function carregarDados($arq) { 
    return file_exists($arq) ? json_decode(file_get_contents($arq), true) ?? [] : []; 
}
function salvarDados($dados, $arq) { 
    $dados['last_update'] = time();
    return file_put_contents($arq, json_encode($dados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); 
}

// Carrega dados
$dados = array_merge([
    'rss_sources' => [], 
    'ads' => [], 
    'titulo_tv' => "TV Corporativa", 
    'tempo_slide' => 15, 
    'max_noticias_total' => 100, 
    'frequencia_ads' => 2
], carregarDados($arquivo_json));

// --- AÇÕES DO FORMULÁRIO ---
$mensagem = ''; $tipo_msg = '';

// 1. Resetar
if (isset($_POST['acao_resetar'])) {
    array_map('unlink', glob("$pastaUploads*"));
    if(file_exists($arquivo_json)) unlink($arquivo_json);
    if(file_exists($cacheFile)) unlink($cacheFile);
    // Não apaga a pasta RSS
    header("Location: admin.php?msg=resetado"); exit;
}

// 2. Upload de Ad
if (isset($_FILES['novo_ad']) && $_FILES['novo_ad']['error'] === UPLOAD_ERR_OK) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($_FILES['novo_ad']['tmp_name']);
    $ext = strtolower(pathinfo($_FILES['novo_ad']['name'], PATHINFO_EXTENSION));
    $permitidos = ['image/jpeg'=>'imagem', 'image/png'=>'imagem', 'video/mp4'=>'video'];

    if (array_key_exists($mime, $permitidos)) {
        $novo = uniqid('ad_') . "." . $ext;
        if (move_uploaded_file($_FILES['novo_ad']['tmp_name'], $pastaUploads . $novo)) {
            $dados['ads'][] = ['arquivo'=>$novo, 'tipo'=>$permitidos[$mime], 'duracao'=>10, 'ordem'=>count($dados['ads'])+1];
            salvarDados($dados, $arquivo_json);
            $mensagem = "Upload realizado com sucesso!"; $tipo_msg = 'sucesso';
        }
    } else {
        $mensagem = "Formato inválido (Use JPG, PNG ou MP4)."; $tipo_msg = 'erro';
    }
}

// 3. Deletar Ad
if (isset($_GET['deletar_ad'])) {
    $id = (int)$_GET['deletar_ad'];
    if (isset($dados['ads'][$id])) {
        @unlink($pastaUploads . $dados['ads'][$id]['arquivo']);
        array_splice($dados['ads'], $id, 1);
        salvarDados($dados, $arquivo_json);
        header("Location: admin.php"); exit;
    }
}

// 4. Salvar Geral
if (isset($_POST['salvar_geral'])) {
    $dados['rss_sources'] = array_slice(array_unique($_POST['rss_sources'] ?? []), 0, $max_rss_selecao);
    $dados['titulo_tv'] = filter_input(INPUT_POST, 'titulo_tv', FILTER_SANITIZE_SPECIAL_CHARS);
    $dados['tempo_slide'] = (int)$_POST['tempo_slide'];
    $dados['max_noticias_total'] = (int)$_POST['max_noticias_total'];
    $dados['frequencia_ads'] = (int)$_POST['frequencia_ads'];
    
    if (isset($_POST['ad_arquivo'])) {
        $novos = [];
        foreach ($_POST['ad_arquivo'] as $i => $arq) {
            $novos[] = [
                'arquivo' => $arq, 
                'tipo' => $_POST['ad_tipo'][$i], 
                'duracao' => (int)$_POST['ad_duracao'][$i], 
                'ordem' => $i + 1
            ];
        }
        $dados['ads'] = $novos;
    } else { $dados['ads'] = []; }
    
    salvarDados($dados, $arquivo_json);
    if(file_exists($cacheFile)) unlink($cacheFile);
    $mensagem = "Configurações salvas!"; $tipo_msg = 'sucesso';
}

if (isset($_GET['msg']) && $_GET['msg'] == 'resetado') {
    $mensagem = "Sistema resetado (Lista de RSS mantida)."; $tipo_msg = 'sucesso';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin TV</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    <style>
        :root { --primary: #2563eb; --danger: #dc2626; --success: #16a34a; --bg: #f3f4f6; --card: #ffffff; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); margin: 0; padding: 20px; color: #1f2937; padding-bottom: 80px; }
        .container { max-width: 1000px; margin: 0 auto; }
        
        header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; background: var(--card); padding: 15px 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        h1 { margin: 0; font-size: 20px; display: flex; align-items: center; gap: 10px; color: #111827; }
        
        .btn { text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; font-size: 14px; border: none; cursor: pointer; color: white; background: var(--primary); transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; }
        .btn-tv { background: var(--success); }
        .btn-tv:hover { background: #15803d; }
        .btn-save { width: 100%; justify-content: center; padding: 16px; font-size: 16px; margin-top: 20px; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2); }
        .btn-save:hover { background: #1d4ed8; transform: translateY(-1px); }
        .btn-outline { background: transparent; border: 1px solid var(--primary); color: var(--primary); padding: 5px 10px; font-size: 12px; }
        .btn-outline:hover { background: #eff6ff; }

        .tabs { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px; }
        .tab-btn { background: #e5e7eb; border: none; padding: 12px 24px; border-radius: 30px; cursor: pointer; font-weight: 600; white-space: nowrap; color: #4b5563; }
        .tab-btn.active { background: var(--primary); color: white; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.3); }
        .tab-content { display: none; animation: fadeIn 0.3s; }
        .tab-content.active { display: block; }

        .card { background: var(--card); padding: 30px; border-radius: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 20px; }
        h2 { margin-top: 0; border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; font-size: 18px; color: #111827; }
        h4 { color: var(--primary); margin: 20px 0 10px 0; font-size: 15px; }
        
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px; color: #374151; }
        input[type=text], input[type=number] { width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; background: #f9fafb; }
        
        .upload-area { border: 2px dashed #cbd5e1; border-radius: 12px; padding: 40px; text-align: center; cursor: pointer; transition: 0.2s; background: #f8fafc; position: relative; margin-bottom: 20px; display: block; }
        .upload-area:hover, .upload-area.highlight { border-color: var(--primary); background: #eff6ff; }
        .upload-icon { font-size: 40px; color: #94a3b8; margin-bottom: 15px; }

        .ads-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 20px; margin-top: 20px; }
        .ad-card { background: white; border: 1px solid #e5e7eb; border-radius: 10px; overflow: hidden; position: relative; cursor: move; transition: all 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .ad-card:hover { transform: translateY(-2px); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); }
        .ad-preview { width: 100%; height: 110px; object-fit: cover; background: #000; }
        .ad-body { padding: 12px; }
        .badge { font-size: 10px; padding: 4px 8px; border-radius: 4px; font-weight: bold; position: absolute; top: 8px; left: 8px; background: rgba(0,0,0,0.7); color: white; backdrop-filter: blur(4px); }
        .btn-del { width: 100%; background: #fee2e2; color: var(--danger); border: none; padding: 8px; border-radius: 6px; cursor: pointer; font-size: 12px; margin-top: 8px; font-weight: 600; }
        .btn-del:hover { background: #fecaca; }

        .rss-item { display: flex; align-items: center; padding: 10px; border-bottom: 1px solid #f3f4f6; transition: 0.1s; cursor: pointer; border-radius: 6px; }
        .rss-item:hover { background: #f9fafb; }
        .rss-item input { width: 18px; height: 18px; margin-right: 12px; accent-color: var(--primary); }

        .msg { padding: 15px; border-radius: 8px; margin-bottom: 25px; text-align: center; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .msg.sucesso { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .msg.erro { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        
        @keyframes fadeIn { from { opacity:0; transform: translateY(5px); } to { opacity:1; transform: translateY(0); } }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1><i class="fa-solid fa-tv" style="color:var(--primary)"></i> Admin TV</h1>
        <div class="actions">
            <a href="index.html" target="_blank" class="btn btn-tv"><i class="fa-solid fa-external-link-alt"></i> Visualizar TV</a>
        </div>
    </header>

    <?php if($mensagem): ?>
        <div class="msg <?php echo $tipo_msg; ?>">
            <i class="fa-solid <?php echo $tipo_msg == 'sucesso' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <div class="tabs">
        <button class="tab-btn active" data-tab="geral" onclick="switchTab('geral', this)"><i class="fa-solid fa-sliders"></i> Configurações</button>
        <button class="tab-btn" data-tab="noticias" onclick="switchTab('noticias', this)"><i class="fa-solid fa-rss"></i> Notícias</button>
        <button class="tab-btn" data-tab="ads" onclick="switchTab('ads', this)"><i class="fa-solid fa-images"></i> Mídia & Ads</button>
        <button class="tab-btn" data-tab="sistema" onclick="switchTab('sistema', this)"><i class="fa-solid fa-cogs"></i> Sistema</button>
    </div>

    <form method="POST" enctype="multipart/form-data" id="mainForm">
        
        <!-- ABA GERAL -->
        <div id="geral" class="tab-content active">
            <div class="card">
                <h2>Ajustes Gerais</h2>
                <div class="form-group">
                    <label>Título da TV</label>
                    <input type="text" name="titulo_tv" value="<?php echo htmlspecialchars($dados['titulo_tv']); ?>" placeholder="Ex: TV Recepção">
                </div>
                <div style="display:flex; gap:20px">
                    <div style="flex:1" class="form-group">
                        <label>Tempo por Slide (seg)</label>
                        <input type="number" name="tempo_slide" value="<?php echo $dados['tempo_slide']; ?>">
                    </div>
                    <div style="flex:1" class="form-group">
                        <label>Máx. Notícias</label>
                        <input type="number" name="max_noticias_total" value="<?php echo $dados['max_noticias_total']; ?>">
                    </div>
                </div>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Alterações</button>
        </div>

        <!-- ABA NOTICIAS -->
        <div id="noticias" class="tab-content">
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                    <h2 style="margin:0">Fontes RSS</h2>
                    <button type="button" class="btn btn-outline" onclick="toggleRSS()"><i class="fa-solid fa-check-double"></i> Marcar/Desmarcar Todos</button>
                </div>

                <div style="background:#eff6ff; color:#2563eb; padding:12px 15px; border-radius:8px; display:flex; justify-content:space-between; font-weight:bold; font-size:14px; margin-bottom:15px; border:1px solid #dbeafe;">
                    <span><i class="fa-solid fa-check"></i> Fontes selecionadas:</span>
                    <span id="rss-count">0 / <?php echo $max_rss_selecao; ?></span>
                </div>

                <p style="font-size:12px; color:#666; margin-bottom:20px; background:#f0f9ff; padding:10px; border-radius:6px; border:1px solid #bae6fd;">
                    <i class="fa-solid fa-info-circle"></i> As fontes abaixo são lidas do arquivo: <strong>rss/rss_links.txt</strong>
                </p>
                <?php if(empty($rss_sugestoes)): ?>
                    <p style="color:#666; font-style:italic; padding:20px; text-align:center; background:#f9fafb;">Nenhuma fonte encontrada. Verifique se o arquivo <strong>rss/rss_links.txt</strong> contém links no formato: Categoria|Link</p>
                <?php else: ?>
                    <?php foreach($rss_sugestoes as $cat => $links): ?>
                        <h4><?php echo htmlspecialchars($cat); ?></h4>
                        <?php foreach($links as $link): ?>
                            <label class="rss-item">
                                <input type="checkbox" name="rss_sources[]" class="chk-rss" value="<?php echo $link; ?>" <?php echo in_array($link, $dados['rss_sources'])?'checked':''; ?>> 
                                <span style="font-size:13px; color:#333; word-break:break-all;"><?php echo $link; ?></span>
                            </label>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Seleção</button>
        </div>

        <!-- ABA ADS -->
        <div id="ads" class="tab-content">
            <div class="card">
                <h2>Gestão de Anúncios</h2>
                <div class="form-group" style="max-width:300px; margin-bottom:20px;">
                    <label>Frequência (Exibir 1 anúncio a cada X notícias)</label>
                    <input type="number" name="frequencia_ads" value="<?php echo $dados['frequencia_ads']; ?>">
                </div>

                <label class="upload-area" id="drop-zone">
                    <input type="file" name="novo_ad" id="fileInput" style="display:none" onchange="this.form.submit()">
                    <div class="upload-icon"><i class="fa-solid fa-cloud-arrow-up"></i></div>
                    <strong>Clique ou Arraste arquivos aqui</strong><br>
                    <span style="font-size:13px; color:#64748b; margin-top:5px; display:block">Suporta JPG, PNG ou MP4</span>
                </label>

                <div class="ads-grid" id="lista-ads">
                    <?php foreach($dados['ads'] as $idx => $ad): ?>
                    <div class="ad-card">
                        <span class="badge"><?php echo strtoupper($ad['tipo']); ?></span>
                        <input type="hidden" name="ad_arquivo[]" value="<?php echo $ad['arquivo']; ?>">
                        <input type="hidden" name="ad_tipo[]" value="<?php echo $ad['tipo']; ?>">
                        
                        <?php if($ad['tipo'] == 'video'): ?>
                            <video src="<?php echo $pastaUploads . $ad['arquivo']; ?>" class="ad-preview"></video>
                            <input type="hidden" name="ad_duracao[]" value="0">
                        <?php else: ?>
                            <img src="<?php echo $pastaUploads . $ad['arquivo']; ?>" class="ad-preview">
                        <?php endif; ?>

                        <div class="ad-body">
                            <?php if($ad['tipo'] != 'video'): ?>
                            <label style="font-size:11px; margin-bottom:2px">Duração (s)</label>
                            <input type="number" name="ad_duracao[]" value="<?php echo $ad['duracao']; ?>" style="padding:6px; font-size:12px; text-align:center; width:100%">
                            <?php else: ?>
                            <p style="font-size:11px; margin:5px 0; color:#666; font-style:italic"><i class="fa-regular fa-clock"></i> Tempo Automático</p>
                            <?php endif; ?>
                            
                            <button type="button" class="btn-del" onclick="if(confirm('Apagar este arquivo?')) window.location.href='?deletar_ad=<?php echo $idx; ?>'">
                                <i class="fa-solid fa-trash"></i> Excluir
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if(empty($dados['ads'])): ?>
                    <div style="text-align:center; padding:30px; color:#9ca3af; background:#f9fafb; border-radius:12px; border:1px dashed #e5e7eb; margin-top:20px;">
                        <i class="fa-regular fa-folder-open" style="font-size:30px; margin-bottom:10px"></i>
                        <p>Nenhum anúncio cadastrado.</p>
                    </div>
                <?php endif; ?>
            </div>
            <button type="submit" name="salvar_geral" class="btn btn-save"><i class="fa-solid fa-save"></i> Salvar Ordem e Tempos</button>
        </div>
    </form>

    <!-- ABA SISTEMA -->
    <div id="sistema" class="tab-content">
        <div class="card" style="border-left: 5px solid var(--danger);">
            <h2 style="color:var(--danger)"><i class="fa-solid fa-triangle-exclamation"></i> Zona de Perigo</h2>
            <p style="color:#4b5563; margin-bottom:20px">Esta ação irá apagar configurações, anúncios e cache. <br><strong>A lista de links RSS (txt) será MANTIDA.</strong></p>
            <form method="POST">
                <input type="hidden" name="acao_resetar" value="1">
                <button type="submit" class="btn" style="background:var(--danger); color:white; width:100%; padding:15px; font-size:15px" onclick="return confirm('Tem certeza absoluta?')">
                    <i class="fa-solid fa-trash-can"></i> FORMATAR SISTEMA
                </button>
            </form>
        </div>
    </div>
</div>

<script>
    function switchTab(id, btn) {
        document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
        document.getElementById(id).classList.add('active');
        if(btn) btn.classList.add('active');
        localStorage.setItem('activeTab', id);
    }

    document.addEventListener("DOMContentLoaded", () => {
        const savedTab = localStorage.getItem('activeTab') || 'geral';
        const btnTab = document.querySelector(`button[data-tab="${savedTab}"]`);
        if(btnTab) switchTab(savedTab, btnTab);
    });

    const MAX_RSS = <?php echo $max_rss_selecao; ?>;
    const checks = document.querySelectorAll('.chk-rss');
    const display = document.getElementById('rss-count');

    function updateCount() {
        const total = document.querySelectorAll('.chk-rss:checked').length;
        if(display) {
            display.textContent = `${total} / ${MAX_RSS}`;
            display.style.color = total > MAX_RSS ? '#ef4444' : (total === MAX_RSS ? '#eab308' : '#2563eb');
        }
    }

    function toggleRSS() {
        const allChecked = Array.from(checks).every(c => c.checked);
        checks.forEach(chk => {
            if(allChecked) {
                chk.checked = false;
            } else {
                const current = document.querySelectorAll('.chk-rss:checked').length;
                if(current < MAX_RSS) chk.checked = true;
            }
        });
        updateCount();
    }

    checks.forEach(chk => {
        chk.addEventListener('change', function() {
            if(this.checked && document.querySelectorAll('.chk-rss:checked').length > MAX_RSS) {
                this.checked = false;
                alert(`Máximo de ${MAX_RSS} fontes permitidas!`);
            }
            updateCount();
        });
    });
    updateCount();

    new Sortable(document.getElementById('lista-ads'), { 
        animation: 150, 
        handle: '.ad-card',
        ghostClass: 'sortable-ghost'
    });

    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('fileInput');
    const form = document.getElementById('mainForm');

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(e => {
        dropZone.addEventListener(e, ev => { ev.preventDefault(); ev.stopPropagation(); });
    });
    ['dragenter', 'dragover'].forEach(e => dropZone.addEventListener(e, () => dropZone.classList.add('highlight')));
    ['dragleave', 'drop'].forEach(e => dropZone.addEventListener(e, () => dropZone.classList.remove('highlight')));

    dropZone.addEventListener('drop', e => {
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            form.submit();
        }
    });
</script>
</body>
</html>