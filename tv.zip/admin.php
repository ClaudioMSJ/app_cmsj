<?php
$arquivo_json = 'config.json';
$pasta_uploads = 'uploads/';
$mensagem = '';
$tipo_msg = '';

$rss_sugestoes = [
    'Notícias Gerais' => [
        'https://g1.globo.com/rss/g1/brasil/',
        'http://rss.uol.com.br/feed/noticias.xml',
        'https://feeds.folha.uol.com.br/emcimadahora/rss091.xml',
        'https://www.cnnbrasil.com.br/feed/',
        'https://jovempan.com.br/feed',
        'https://feeds.bbci.co.uk/portuguese/rss.xml',
        'https://www.nexojornal.com.br/rss.xml'
    ],
    'Economia e Finanças' => [
        'https://www.infomoney.com.br/feed/',
        'http://rss.uol.com.br/feed/economia.xml',
        'https://g1.globo.com/rss/g1/economia/',
        'https://www.estadao.com.br/rss/economia'
    ],
    'Tecnologia e Ciência' => [
        'https://rss.tecmundo.com.br/feed',
        'https://olhardigital.com.br/rss',
        'https://g1.globo.com/rss/g1/tecnologia/',
        'https://canaltech.com.br/rss/',
        'https://macmagazine.com.br/feed/'
    ],
    'Política' => [
        'https://g1.globo.com/rss/g1/politica/',
        'https://feeds.folha.uol.com.br/poder/rss091.xml',
        'https://congressoemfoco.uol.com.br/feed/'
    ],
    'Esportes' => [
        'http://rss.uol.com.br/feed/esporte.xml',
        'https://www.gazetaesportiva.com/feed/',
        'https://www.espn.com.br/espn/rss/news'
    ]
];

if (!is_dir($pasta_uploads)) mkdir($pasta_uploads, 0777, true);

function salvarDados($dados, $arquivo) {
    $dados['last_update'] = time(); 
    return file_put_contents($arquivo, json_encode($dados, JSON_PRETTY_PRINT));
}

if (isset($_POST['acao_resetar'])) {
    $arquivos = glob($pasta_uploads . '*');
    foreach($arquivos as $arquivo) if(is_file($arquivo)) @unlink($arquivo);

    $padrao = [
        "rss_sources" => [],
        "ads" => [],
        "titulo_tv" => "TV Corporativa",
        "tempo_slide" => 15,
        "max_noticias_total" => 20,
        "frequencia_ads" => 2,
        "last_update" => time()
    ];
    
    if (salvarDados($padrao, $arquivo_json)) {
        header("Location: admin.php?msg=resetado"); exit;
    }
}

if (isset($_GET['msg']) && $_GET['msg'] == 'resetado') {
    $mensagem = "Sistema zerado!"; $tipo_msg = 'sucesso';
}

$dados = [];
if (file_exists($arquivo_json)) {
    $dados = json_decode(file_get_contents($arquivo_json), true);
    if (!is_array($dados)) $dados = [];
}

$dados['rss_sources'] = isset($dados['rss_sources']) ? $dados['rss_sources'] : [];
$dados['ads'] = isset($dados['ads']) ? $dados['ads'] : [];
$dados['titulo_tv'] = isset($dados['titulo_tv']) ? $dados['titulo_tv'] : "TV Corporativa";
$dados['tempo_slide'] = isset($dados['tempo_slide']) ? $dados['tempo_slide'] : 15;
$dados['max_noticias_total'] = isset($dados['max_noticias_total']) ? $dados['max_noticias_total'] : 20;
$dados['frequencia_ads'] = isset($dados['frequencia_ads']) ? $dados['frequencia_ads'] : 2;

if (isset($_FILES['novo_ad'])) {
    if ($_FILES['novo_ad']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['novo_ad']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'mp4'])) {
            $novoNome = uniqid() . "." . $ext;
            $destino = $pasta_uploads . $novoNome;
            if (move_uploaded_file($_FILES['novo_ad']['tmp_name'], $destino)) {
                $dados['ads'][] = [
                    'arquivo' => $novoNome, 'tipo' => ($ext == 'mp4' ? 'video' : 'imagem'),
                    'duracao' => 10, 'ordem' => count($dados['ads']) + 1
                ];
                salvarDados($dados, $arquivo_json);
                $mensagem = "Arquivo adicionado!"; $tipo_msg = 'sucesso';
            } else { $mensagem = "Erro permissão."; $tipo_msg = 'erro'; }
        } else { $mensagem = "Formato inválido."; $tipo_msg = 'erro'; }
    }
}

if (isset($_GET['deletar_ad'])) {
    $id = (int)$_GET['deletar_ad'];
    if (isset($dados['ads'][$id])) {
        @unlink($pasta_uploads . $dados['ads'][$id]['arquivo']);
        array_splice($dados['ads'], $id, 1);
        salvarDados($dados, $arquivo_json);
        header("Location: admin.php"); exit;
    }
}

if (isset($_POST['salvar_geral'])) {
    $novosRss = [];
    if (isset($_POST['rss_sources'])) foreach ($_POST['rss_sources'] as $u) if(!empty(trim($u))) $novosRss[]=trim($u);
    
    $dados['rss_sources'] = array_values(array_unique($novosRss));
    $dados['titulo_tv'] = $_POST['titulo_tv'];
    $dados['tempo_slide'] = (int)$_POST['tempo_slide'];
    $dados['max_noticias_total'] = (int)$_POST['max_noticias_total'];
    $dados['frequencia_ads'] = (int)$_POST['frequencia_ads'];

    $novosAds = [];
    if (isset($_POST['ad_arquivo']) && is_array($_POST['ad_arquivo'])) {
        foreach ($_POST['ad_arquivo'] as $index => $arquivo) {
            $novosAds[] = [
                'arquivo' => $arquivo,
                'tipo'    => $_POST['ad_tipo'][$index],
                'duracao' => (int)$_POST['ad_duracao'][$index],
                'ordem'   => $index + 1
            ];
        }
    }
    $dados['ads'] = $novosAds;

    salvarDados($dados, $arquivo_json);
    $mensagem = "Configurações salvas! A TV atualizará em instantes."; $tipo_msg = 'sucesso';
}

$todos_presets = [];
foreach ($rss_sugestoes as $cat => $urls) {
    foreach ($urls as $url) $todos_presets[] = $url;
}
$custom_rss = array_diff($dados['rss_sources'], $todos_presets);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <!-- META TAG VIEWPORT ESSENCIAL PARA CELULAR -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Admin TV</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    <style>
        /* RESET BÁSICO E FONTE */
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body { font-family: 'Segoe UI', Roboto, Helvetica, sans-serif; background: #f4f6f9; margin: 0; padding: 15px; color: #333; padding-bottom: 80px; }
        
        /* CONTAINER PRINCIPAL */
        .container { max-width: 900px; margin: auto; }

        /* CABEÇALHO FLEXÍVEL */
        .header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px; }
        h1 { margin: 0; font-size: 24px; }
        .btn-abrir-tv { background: #2ecc71; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 14px; text-align: center; }

        /* ABAS */
        .tab-nav { display: flex; gap: 5px; margin-bottom: 0; border-bottom: 3px solid #2980b9; overflow-x: auto; white-space: nowrap; padding-bottom: 2px; }
        .tab-btn {
            padding: 12px 20px;
            background: #e0e0e0;
            border: none;
            border-radius: 8px 8px 0 0;
            cursor: pointer;
            font-weight: bold;
            color: #555;
            transition: 0.2s;
            font-size: 14px;
            flex-shrink: 0; /* Impede que o botão amasse */
        }
        .tab-btn:hover { background: #d0d0d0; }
        .tab-btn.active { background: #2980b9; color: white; }
        
        /* CONTEÚDO DAS ABAS */
        .tab-content { display: none; background: white; padding: 20px; border-radius: 0 0 8px 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); animation: fadeIn 0.3s; }
        .tab-content.active { display: block; }
        @keyframes fadeIn { from { opacity:0; transform: translateY(5px); } to { opacity:1; transform: translateY(0); } }

        /* ELEMENTOS DE FORMULÁRIO */
        h2 { margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; color: #2c3e50; font-size: 20px; }
        h3 { margin: 20px 0 10px 0; color: #2980b9; font-size: 16px; border-left: 4px solid #2980b9; padding-left: 10px; }
        
        input[type=text], input[type=number] { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; /* Fonte maior para celular não dar zoom */ }
        
        .form-row { display: flex; gap: 15px; }
        .form-col { flex: 1; }

        .btn { padding: 14px; cursor: pointer; border: none; border-radius: 4px; color: white; font-weight: bold; font-size: 16px; width: 100%; display: block; }
        .save { background: #2980b9; margin-top: 20px; }
        .save:hover { background: #1f6391; }
        .add { background: #7f8c8d; width: auto; display: inline-block; padding: 10px 20px; margin-top: 10px; }
        .btn-reset { background: #c0392b; color: white; width: 100%; padding: 15px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; margin-top: 10px; font-size: 14px; }
        
        /* LISTA DE ADS */
        #lista-ads { display: flex; flex-wrap: wrap; gap: 15px; margin-top: 20px; justify-content: flex-start; }
        .ad-item { 
            border: 1px solid #ddd; padding: 10px; border-radius: 5px; 
            background: #fff; width: 140px; text-align: center; cursor: grab;
            display: flex; flex-direction: column; justify-content: space-between;
            position: relative;
        }
        .preview { width: 100%; height: 90px; object-fit: cover; background: #000; margin-bottom: 5px; border-radius: 3px; pointer-events: none; }
        .lbl-tiny { font-size: 11px; font-weight: bold; color: #666; }
        .tiny-input { width: 60px !important; padding: 5px !important; text-align: center; margin: 0 auto !important; cursor: text !important; font-size: 14px !important; }
        .del { color: #e74c3c; font-size: 12px; display: block; margin-top: 8px; cursor: pointer; padding: 5px; border: 1px solid #eee; border-radius: 4px; }
        
        /* RSS CUSTOMIZADO */
        .rss-custom-row { display: flex; gap: 5px; margin-bottom: 10px; }
        .rss-custom-row input { margin-bottom: 0; }
        .btn-del-rss { background: #e74c3c; color: white; border: none; cursor: pointer; border-radius: 4px; width: 50px; font-size: 18px; }

        /* MENSAGENS */
        .msg { padding: 15px; border-radius: 4px; margin-bottom: 15px; text-align: center; font-weight: bold; }
        .sucesso { background: #d4edda; color: #155724; }
        .erro { background: #f8d7da; color: #721c24; }

        .rss-item { padding: 8px 0; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid #f0f0f0; }
        .rss-item input[type=checkbox] { transform: scale(1.5); cursor: pointer; margin-right: 10px; }
        .rss-url { font-size: 14px; color: #555; word-break: break-all; line-height: 1.4; }

        /* MODAL RESPONSIVO */
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.6); z-index: 2000; justify-content: center; align-items: center;
            backdrop-filter: blur(3px); padding: 20px;
        }
        .modal-box {
            background: white; padding: 25px; border-radius: 12px;
            width: 100%; max-width: 350px; text-align: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2); animation: popIn 0.2s;
        }
        @keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .modal-title { font-size: 20px; font-weight: bold; margin-bottom: 15px; color: #c0392b; }
        .modal-actions { display: flex; gap: 10px; justify-content: center; margin-top: 25px; }
        .btn-modal { flex: 1; padding: 12px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 15px; }
        .btn-nao { background: #ecf0f1; color: #333; }
        .btn-sim { background: #e74c3c; color: white; }

        /* --- MEDIA QUERIES (CELULAR) --- */
        @media (max-width: 600px) {
            body { padding: 10px; padding-bottom: 60px; }
            
            /* Header empilhado */
            .header-top { flex-direction: column; text-align: center; gap: 15px; }
            .btn-abrir-tv { width: 100%; display: block; }
            
            /* Abas roláveis ou empilhadas */
            .tab-nav { flex-wrap: nowrap; overflow-x: auto; -webkit-overflow-scrolling: touch; }
            .tab-btn { padding: 12px 15px; font-size: 13px; }
            
            /* Inputs empilhados */
            .form-row { flex-direction: column; gap: 0; }
            
            /* Cards de propaganda esticados */
            #lista-ads { gap: 10px; justify-content: space-between; }
            .ad-item { width: 48%; /* 2 por linha */ margin-bottom: 10px; flex-grow: 1; }
            
            /* Checkbox maior */
            .rss-item { padding: 12px 0; }
            .rss-item input[type=checkbox] { transform: scale(1.4); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-top">
            <h1>📺 Painel Admin</h1>
            <a href="index.php" target="_blank" class="btn-abrir-tv">Abrir TV ➡️</a>
        </div>

        <?php if($mensagem): ?><div class="msg <?php echo $tipo_msg; ?>"><?php echo $mensagem; ?></div><?php endif; ?>

        <div class="tab-nav">
            <button class="tab-btn" onclick="openTab('tab-geral', this)">⚙️ Geral</button>
            <button class="tab-btn" onclick="openTab('tab-noticias', this)">📰 Notícias</button>
            <button class="tab-btn" onclick="openTab('tab-ads', this)">📢 Ads</button>
            <button class="tab-btn" onclick="openTab('tab-sistema', this)">⚠️ Sistema</button>
        </div>

        <form method="POST" enctype="multipart/form-data">
            
            <div id="tab-geral" class="tab-content">
                <h2>Configurações Gerais</h2>
                <label>Título da TV (Cabeçalho)</label>
                <input type="text" name="titulo_tv" value="<?php echo htmlspecialchars($dados['titulo_tv']); ?>">
                
                <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
                
                <div class="form-row">
                    <div class="form-col">
                        <label>Tempo por Notícia (s)</label>
                        <input type="number" name="tempo_slide" value="<?php echo $dados['tempo_slide']; ?>">
                    </div>
                    <div class="form-col">
                        <label>Máx. Notícias (Total)</label>
                        <input type="number" name="max_noticias_total" value="<?php echo $dados['max_noticias_total']; ?>">
                    </div>
                </div>

                <button type="submit" name="salvar_geral" class="btn save">💾 Salvar Configurações</button>
            </div>

            <div id="tab-noticias" class="tab-content">
                <h2>Fontes de Notícias</h2>
                <p style="color:#666;font-size:13px;margin-bottom:20px;">Toque para selecionar os canais.</p>
                
                <?php foreach($rss_sugestoes as $categoria => $links): ?>
                    <h3><?php echo $categoria; ?></h3>
                    <div style="background:#f9f9f9; padding:10px; border-radius:5px; margin-bottom:10px;">
                    <?php foreach($links as $link): 
                        $checked = in_array($link, $dados['rss_sources']) ? 'checked' : '';
                    ?>
                        <label class="rss-item">
                            <input type="checkbox" name="rss_sources[]" value="<?php echo $link; ?>" <?php echo $checked; ?>>
                            <span class="rss-url"><?php echo $link; ?></span>
                        </label>
                    <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>

                <h3>Personalizadas</h3>
                <div id="rss-list">
                    <?php foreach($custom_rss as $url): ?>
                    <div class="rss-custom-row">
                        <input type="text" name="rss_sources[]" value="<?php echo htmlspecialchars($url); ?>">
                        <button type="button" class="btn-del-rss" onclick="this.parentElement.remove()">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="btn add" onclick="addRss()">+ Adicionar Link</button>

                <button type="submit" name="salvar_geral" class="btn save">💾 Salvar Seleção</button>
            </div>

            <div id="tab-ads" class="tab-content">
                <h2>Mídia e Propagandas</h2>

                <div style="background:#e8f4fd;padding:15px;border-radius:5px;margin-bottom:20px;">
                    <label style="font-weight:bold;color:#2980b9;">Frequência</label>
                    <p style="margin:5px 0 10px 0;font-size:13px;color:#666;">Mostrar ads a cada X notícias.</p>
                    <input type="number" name="frequencia_ads" value="<?php echo $dados['frequencia_ads']; ?>">
                </div>
                
                <div style="background:#f9f9f9;padding:20px;border:2px dashed #ccc;text-align:center;border-radius:8px;">
                    <label style="cursor:pointer;display:block;">
                        <strong style="font-size:16px;color:#2980b9;">📤 Enviar Arquivo</strong><br>
                        <span style="font-size:12px;color:#777;">(JPG/PNG/MP4)</span>
                        <input type="file" name="novo_ad" onchange="this.form.submit()" style="display:none;">
                    </label>
                </div>

                <div id="lista-ads">
                    <?php if(empty($dados['ads'])): ?>
                        <p style="width:100%;text-align:center;color:#999;margin-top:30px;">Nenhuma propaganda.</p>
                    <?php else: ?>
                        <?php foreach($dados['ads'] as $index => $ad): ?>
                            <div class="ad-item">
                                <input type="hidden" name="ad_arquivo[]" value="<?php echo $ad['arquivo']; ?>">
                                <input type="hidden" name="ad_tipo[]" value="<?php echo $ad['tipo']; ?>">
                                
                                <?php if($ad['tipo']=='video'): ?>
                                    <video src="uploads/<?php echo $ad['arquivo']; ?>" class="preview"></video>
                                <?php else: ?>
                                    <img src="uploads/<?php echo $ad['arquivo']; ?>" class="preview">
                                <?php endif; ?>
                                
                                <div>
                                    <span class="lbl-tiny">Tempo (s)</span><br>
                                    <?php if($ad['tipo'] == 'video'): ?>
                                        <span style="font-size:11px; color:#777; font-style: italic; display:block; padding:6px;">Auto</span>
                                        <input type="hidden" name="ad_duracao[]" value="0">
                                    <?php else: ?>
                                        <input type="number" name="ad_duracao[]" class="tiny-input" value="<?php echo isset($ad['duracao']) ? $ad['duracao'] : 10; ?>">
                                    <?php endif; ?>
                                </div>
                                <span class="del" onclick="confirmarExclusao('?deletar_ad=<?php echo $index; ?>')">🗑️ Excluir</span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <p style="font-size:12px;color:#666;margin-top:20px;text-align:center;">Segure e arraste para ordenar.</p>
                <button type="submit" name="salvar_geral" class="btn save">💾 Salvar Alterações</button>
            </div>

        </form>

        <div id="tab-sistema" class="tab-content">
            <h2 style="color:#c0392b;">Zona de Perigo</h2>
            <p>Esta ação irá apagar <strong>todas</strong> as configurações e arquivos.</p>
            
            <form method="POST" style="margin-top:20px;">
                <input type="hidden" name="acao_resetar" value="1">
                <button type="submit" class="btn-reset" onclick="return confirm('Tem certeza absoluta?')">🗑️ RESETAR SISTEMA</button>
            </form>
        </div>
    </div>

    <!-- MODAL -->
    <div id="modal-confirm" class="modal-overlay">
        <div class="modal-box">
            <div class="modal-title">🗑️ Excluir Mídia</div>
            <p>Deseja realmente apagar este arquivo?</p>
            <div class="modal-actions">
                <button class="btn-modal btn-nao" onclick="fecharModal()">Cancelar</button>
                <button class="btn-modal btn-sim" id="btn-confirmar-del">Sim, Excluir</button>
            </div>
        </div>
    </div>

    <script>
    // Correção para permitir digitação no celular dentro do Sortable
    new Sortable(document.getElementById('lista-ads'), { 
        animation: 150,
        filter: 'input', 
        preventOnFilter: false,
        delay: 100, // Adiciona um pequeno delay no toque para evitar arrastar sem querer ao rolar a tela
        touchStartThreshold: 3 // Sensibilidade do toque
    });

    function addRss(){
        let div = document.createElement('div'); 
        div.className = 'rss-custom-row';
        div.innerHTML = '<input type="text" name="rss_sources[]" placeholder="https://..."><button type="button" class="btn-del-rss" onclick="this.parentElement.remove()">✕</button>';
        document.getElementById('rss-list').appendChild(div);
    }

    function openTab(tabId, btnElement) {
        document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));

        document.getElementById(tabId).classList.add('active');
        if(btnElement) btnElement.classList.add('active');
        localStorage.setItem('admin_tab', tabId);
    }

    function confirmarExclusao(url) {
        const modal = document.getElementById('modal-confirm');
        const btnSim = document.getElementById('btn-confirmar-del');
        btnSim.onclick = function() { window.location.href = url; };
        modal.style.display = 'flex';
    }

    function fecharModal() {
        document.getElementById('modal-confirm').style.display = 'none';
    }

    document.getElementById('modal-confirm').addEventListener('click', function(e) {
        if (e.target === this) fecharModal();
    });

    document.addEventListener("DOMContentLoaded", function() {
        const savedTab = localStorage.getItem('admin_tab') || 'tab-geral';
        const btn = document.querySelector(`button[onclick*="${savedTab}"]`);
        if(document.getElementById(savedTab)) openTab(savedTab, btn);
    });
    </script>
</body>
</html>