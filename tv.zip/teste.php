<?php
// ARQUIVO: index.php

// --- CONFIGURAÇÕES ---
$arquivo_json = 'config.json';
$arquivo_cache = 'cache_news.json';
$pasta_uploads = 'uploads/';
$tempo_cache = 900; // 15 minutos (em segundos)

// --- FUNÇÕES AUXILIARES ---

function carregarConfig($arquivo) {
    if (file_exists($arquivo)) {
        return json_decode(file_get_contents($arquivo), true);
    }
    return [];
}

// Tenta extrair imagem de RSS (Enclosure, Media Content ou Tag IMG na descrição)
function extrairImagem($item, $ns) {
    // 1. Tenta tag <enclosure>
    if (isset($item->enclosure) && isset($item->enclosure['url'])) {
        return (string)$item->enclosure['url'];
    }
    
    // 2. Tenta media:content
    if ($ns && isset($ns['media'])) {
        $media = $item->children($ns['media']);
        if (isset($media->content) && isset($media->content->attributes()['url'])) {
            return (string)$media->content->attributes()['url'];
        }
    }

    // 3. Tenta regex na descrição
    preg_match('/<img.+src=[\'"](?P<src>.+?)[\'"].*>/i', (string)$item->description, $image);
    if (isset($image['src'])) {
        return $image['src'];
    }

    return null; // Sem imagem
}

// Busca notícias e salva em cache
function atualizarNoticias($fontes, $max_total, $cache_file) {
    $noticias = [];

    // Se não houver fontes, retorna vazio
    if (empty($fontes)) return [];

    foreach ($fontes as $url) {
        try {
            $content = @file_get_contents($url);
            if ($content) {
                $xml = simplexml_load_string($content);
                if ($xml) {
                    $ns = $xml->getNamespaces(true);
                    $count = 0;
                    foreach ($xml->channel->item as $item) {
                        if ($count >= 5) break; // Pega max 5 por feed para misturar
                        
                        $img = extrairImagem($item, $ns);
                        
                        $noticias[] = [
                            'tipo' => 'noticia',
                            'titulo' => strip_tags((string)$item->title),
                            'texto' => strip_tags(substr((string)$item->description, 0, 200)) . '...',
                            'fonte' => (string)$xml->channel->title,
                            'data' => strtotime((string)$item->pubDate),
                            'imagem' => $img
                        ];
                        $count++;
                    }
                }
            }
        } catch (Exception $e) {
            continue;
        }
    }

    // Ordena por data (mais recente primeiro)
    usort($noticias, function($a, $b) {
        return $b['data'] - $a['data'];
    });

    // Corta para o máximo global
    $noticias = array_slice($noticias, 0, $max_total);

    // Salva cache
    file_put_contents($cache_file, json_encode($noticias));
    return $noticias;
}

// --- LÓGICA DE CARREGAMENTO ---

$config = carregarConfig($arquivo_json);

// Defaults para evitar erros se config não existir
$titulo_tv = $config['titulo_tv'] ?? 'TV Corporativa';
$tempo_slide_padrao = $config['tempo_slide'] ?? 15;
$rss_sources = $config['rss_sources'] ?? [];
$max_noticias = $config['max_noticias_total'] ?? 20;
$frequencia_ads = $config['frequencia_ads'] ?? 2;
$ads = $config['ads'] ?? [];

// Verifica Cache de Notícias
$noticias = [];
if (file_exists($arquivo_cache) && (time() - filemtime($arquivo_cache) < $tempo_cache)) {
    $noticias = json_decode(file_get_contents($arquivo_cache), true);
} else {
    $noticias = atualizarNoticias($rss_sources, $max_noticias, $arquivo_cache);
}

// --- MONTAGEM DA PLAYLIST (Intercalando Notícias e Ads) ---
$playlist = [];
$ad_index = 0;
$news_counter = 0;
$total_ads = count($ads);

if (empty($noticias) && empty($ads)) {
    // Modo de espera se não tiver nada
    $playlist[] = [
        'tipo' => 'aviso',
        'titulo' => 'Bem-vindo',
        'texto' => 'Aguardando configuração de conteúdo...',
        'duracao' => 10
    ];
} else {
    // Se não tiver notícias, mostra só ads, e vice-versa
    if (empty($noticias)) {
        foreach($ads as $ad) {
            $ad['tipo_midia'] = $ad['tipo']; 
            $ad['tipo'] = 'publicidade';
            $ad['path'] = $pasta_uploads . $ad['arquivo'];
            $playlist[] = $ad;
        }
    } elseif (empty($ads)) {
        foreach($noticias as $news) {
            $news['duracao'] = $tempo_slide_padrao;
            $playlist[] = $news;
        }
    } else {
        // Algoritmo de mistura
        foreach ($noticias as $news) {
            $news['duracao'] = $tempo_slide_padrao;
            $playlist[] = $news;
            $news_counter++;

            // Hora de inserir anúncio?
            if ($news_counter >= $frequencia_ads) {
                if ($total_ads > 0) {
                    $ad = $ads[$ad_index % $total_ads]; // Pega o próximo ad (ciclico)
                    $ad['tipo_midia'] = $ad['tipo']; // Renomeia para não confundir com tipo do slide
                    $ad['tipo'] = 'publicidade';
                    $ad['path'] = $pasta_uploads . $ad['arquivo'];
                    
                    $playlist[] = $ad;
                    $ad_index++;
                    $news_counter = 0; // Reseta contador
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo_tv; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #0044cc; --accent: #ffd700; --text-light: #fff; --overlay: rgba(0,0,0,0.7); }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #000; font-family: 'Segoe UI', system-ui, sans-serif; overflow: hidden; height: 100vh; width: 100vw; }
        
        /* HEADER */
        .tv-header {
            position: absolute; top: 0; left: 0; width: 100%; height: 80px;
            background: linear-gradient(to bottom, rgba(0,0,0,0.9), transparent);
            z-index: 10; display: flex; justify-content: space-between; align-items: center;
            padding: 0 40px; color: var(--text-light);
        }
        .tv-title { font-size: 24px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; display: flex; align-items: center; gap: 10px; }
        .tv-clock { font-size: 28px; font-weight: 300; font-variant-numeric: tabular-nums; }
        
        /* CONTAINER PRINCIPAL */
        #stage { position: relative; width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; }
        
        /* SLIDES */
        .slide {
            position: absolute; width: 100%; height: 100%;
            opacity: 0; transition: opacity 1s ease-in-out;
            display: flex; flex-direction: column; justify-content: flex-end;
            background-size: cover; background-position: center;
        }
        .slide.active { opacity: 1; z-index: 2; }
        
        /* LAYOUT NOTÍCIA */
        .news-overlay {
            background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.6) 60%, transparent 100%);
            padding: 60px 50px; padding-bottom: 80px; width: 100%; min-height: 40%;
            display: flex; flex-direction: column; justify-content: flex-end;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
        }
        .news-source { color: var(--accent); font-weight: bold; font-size: 18px; margin-bottom: 10px; text-transform: uppercase; display: inline-block; background: var(--primary); padding: 5px 15px; border-radius: 4px; align-self: flex-start; }
        .news-title { font-size: 48px; color: #fff; margin-bottom: 20px; line-height: 1.2; font-weight: 800; }
        .news-text { font-size: 24px; color: #e5e7eb; max-width: 80%; line-height: 1.5; }
        
        /* LAYOUT FULLSCREEN (ADS) */
        .media-fs { width: 100%; height: 100%; object-fit: cover; }
        
        /* BARRA DE PROGRESSO */
        .progress-bar {
            position: absolute; bottom: 0; left: 0; height: 6px; background: var(--accent);
            width: 0%; z-index: 20;
        }

        /* DEFAULT BG SE NÃO TIVER IMAGEM RSS */
        .bg-gradient { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); }
    </style>
</head>
<body>

    <header class="tv-header">
        <div class="tv-title"><i class="fa-solid fa-tv"></i> <?php echo htmlspecialchars($titulo_tv); ?></div>
        <div class="tv-clock" id="clock">00:00</div>
    </header>

    <div id="stage">
        <!-- O JS vai injetar o conteúdo aqui -->
    </div>
    
    <div class="progress-bar" id="progress"></div>

    <script>
        // Dados vindos do PHP
        const playlist = <?php echo json_encode($playlist); ?>;
        
        // Elementos
        const stage = document.getElementById('stage');
        const progressBar = document.getElementById('progress');
        
        let currentIndex = 0;
        let slideTimeout;
        let progressInterval;

        // Função Relógio
        function updateClock() {
            const now = new Date();
            const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            document.getElementById('clock').innerText = timeString;
        }
        setInterval(updateClock, 1000);
        updateClock();

        // Renderiza o Slide
        function showSlide(index) {
            // Se acabou a playlist, recarrega a página para buscar novas notícias/configs
            if (index >= playlist.length) {
                location.reload(); 
                return;
            }

            const item = playlist[index];
            stage.innerHTML = ''; // Limpa palco
            progressBar.style.width = '0%';
            
            // Container do Slide
            const el = document.createElement('div');
            el.className = 'slide active';

            // --- LÓGICA DE EXIBIÇÃO ---
            
            // 1. PUBLICIDADE VÍDEO
            if (item.tipo === 'publicidade' && item.tipo_midia === 'video') {
                const video = document.createElement('video');
                video.src = item.path;
                video.className = 'media-fs';
                video.autoplay = true;
                video.muted = false; // Tenta com som (pode ser bloqueado pelo navegador se não houver interação)
                
                // Fallback para autoplay policy: muta se der erro
                video.play().catch(() => {
                    video.muted = true;
                    video.play();
                });

                // Quando vídeo acabar, vai pro próximo
                video.onended = nextSlide;
                
                // Barra de progresso baseada no tempo do vídeo
                video.ontimeupdate = () => {
                    if(video.duration) {
                        const pct = (video.currentTime / video.duration) * 100;
                        progressBar.style.width = pct + '%';
                    }
                };
                
                el.appendChild(video);
                stage.appendChild(el);
                
                // Nota: Não usamos setTimeout aqui, usamos o evento onended
                return; 
            }

            // 2. PUBLICIDADE IMAGEM
            else if (item.tipo === 'publicidade' && item.tipo_midia === 'imagem') {
                el.style.backgroundImage = `url('${item.path}')`;
                stage.appendChild(el);
                startTimer(item.duracao);
            }

            // 3. NOTÍCIA
            else if (item.tipo === 'noticia' || item.tipo === 'aviso') {
                // Background
                if (item.imagem) {
                    el.style.backgroundImage = `url('${item.imagem}')`;
                } else {
                    el.classList.add('bg-gradient');
                }

                // Conteúdo Texto
                const html = `
                    <div class="news-overlay">
                        ${item.fonte ? `<div class="news-source"><i class="fa-solid fa-rss"></i> ${item.fonte}</div>` : ''}
                        <div class="news-title">${item.titulo}</div>
                        <div class="news-text">${item.texto}</div>
                    </div>
                `;
                el.innerHTML = html;
                stage.appendChild(el);
                startTimer(item.duracao);
            }
        }

        // Timer e Barra de Progresso (para imagens e notícias)
        function startTimer(seconds) {
            const totalTime = seconds * 1000;
            const intervalTime = 50; // Atualiza a cada 50ms
            let elapsed = 0;

            if (progressInterval) clearInterval(progressInterval);
            
            progressInterval = setInterval(() => {
                elapsed += intervalTime;
                const pct = (elapsed / totalTime) * 100;
                progressBar.style.width = pct + '%';
                
                if (elapsed >= totalTime) {
                    clearInterval(progressInterval);
                    nextSlide();
                }
            }, intervalTime);
        }

        function nextSlide() {
            currentIndex++;
            showSlide(currentIndex);
        }

        // Inicia
        if (playlist.length > 0) {
            showSlide(0);
        } else {
            // Fallback total
            stage.innerHTML = '<h1 style="color:white; text-align:center;">Sem conteúdo configurado. <br>Acesse admin.php</h1>';
        }

    </script>
</body>
</html>