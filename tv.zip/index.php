<?php
// --- INÍCIO: SISTEMA DE ATUALIZAÇÃO AUTOMÁTICA ---
function verificarAtualizacao() {
    // Configurações do Update
    $repoUser = 'ClaudioMSJ';
    $repoName = 'app_cmsj';
    $branch = 'main';
    $arquivoZip = 'tv.zip';
    $arquivoVersao = 'versao_instalada.txt';
    $diretorioDestino = __DIR__;
    
    // URLs
    $urlApi = "https://api.github.com/repos/$repoUser/$repoName/commits/$branch";
    $urlDownload = "https://cdn.jsdelivr.net/gh/$repoUser/$repoName@$branch/$arquivoZip";

    // 1. Verifica versão no GitHub (Timeout curto para não travar a TV)
    $ch = curl_init($urlApi);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'TV-Updater');
    curl_setopt($ch, CURLOPT_TIMEOUT, 5); // Espera max 5 seg pela verificação
    $json = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || empty($json)) return; // Falha silenciosa, segue o baile

    $dados = json_decode($json, true);
    $novaVersao = isset($dados['sha']) ? $dados['sha'] : '';
    $versaoAtual = file_exists($arquivoVersao) ? file_get_contents($arquivoVersao) : '';

    // Se versões forem iguais, não faz nada
    if (empty($novaVersao) || $novaVersao === $versaoAtual) return;

    // 2. Se diferente, baixa a atualização
    $fp = fopen($arquivoZip, 'w+');
    $chDl = curl_init($urlDownload);
    curl_setopt($chDl, CURLOPT_FILE, $fp);
    curl_setopt($chDl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($chDl, CURLOPT_TIMEOUT, 60); // 1 minuto para baixar
    curl_setopt($chDl, CURLOPT_USERAGENT, 'Mozilla/5.0');
    $exec = curl_exec($chDl);
    $codeDl = curl_getinfo($chDl, CURLINFO_HTTP_CODE);
    curl_close($chDl);
    fclose($fp);

    // 3. Extrai e Limpa
    if ($exec && $codeDl == 200) {
        $zip = new ZipArchive;
        if ($zip->open($arquivoZip) === TRUE) {
            $zip->extractTo($diretorioDestino);
            $zip->close();
            file_put_contents($arquivoVersao, $novaVersao);
        }
    }
    // Sempre apaga o ZIP, dando certo ou errado
    if (file_exists($arquivoZip)) unlink($arquivoZip);
}

// Executa a atualização antes de tudo. Se der erro, o PHP ignora e carrega a TV.
verificarAtualizacao();
// --- FIM: SISTEMA DE ATUALIZAÇÃO AUTOMÁTICA ---


// --- INÍCIO: CÓDIGO DA TV CORPORATIVA ---
ini_set('display_errors', 0); error_reporting(E_ALL);
$configFile = 'config.json';
if (!file_exists($configFile)) die("Configure no admin.php");
$json = file_get_contents($configFile);
$config = json_decode($json, true);
if (!$config) die("Erro no JSON");

$lastUpdate = isset($config['last_update']) ? $config['last_update'] : time();
$rssSources = isset($config['rss_sources']) ? $config['rss_sources'] : [];
$maxTotal = isset($config['max_noticias_total']) ? $config['max_noticias_total'] : 20;
$tempoNoticia = (isset($config['tempo_slide']) ? $config['tempo_slide'] : 15) * 1000; 
$frequenciaAds = isset($config['frequencia_ads']) ? $config['frequencia_ads'] : 2;
$ads = isset($config['ads']) ? $config['ads'] : [];
$tituloTv = isset($config['titulo_tv']) ? $config['titulo_tv'] : "TV Corporativa";

function obterImagemContexto($texto) {
    $texto = mb_strtolower($texto, 'UTF-8');
    $banco = [
        'polícia'=>'https://images.unsplash.com/photo-1599256621730-535171e28e50?w=1600',
        'dólar'=>'https://images.unsplash.com/photo-1580519542036-c47de6196ba5?w=1600',
        'economia'=>'https://images.unsplash.com/photo-1611974765270-ca1258634369?w=1600',
        'governo'=>'https://images.unsplash.com/photo-1541872703-74c59636a226?w=1600',
        'futebol'=>'https://images.unsplash.com/photo-1522778119026-d647f0565c73?w=1600',
        'saúde'=>'https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?w=1600',
        'tecnologia'=>'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1600'
    ];
    foreach ($banco as $k => $v) { if (stripos($texto, $k) !== false) return $v; }
    return null;
}

function obterCorFonte($nome) {
    $nome = mb_strtolower($nome, 'UTF-8');
    if (stripos($nome, 'g1') !== false) return '#C4170C';
    if (stripos($nome, 'uol') !== false) return '#F9A01B';
    if (stripos($nome, 'folha') !== false) return '#004D8C';
    if (stripos($nome, 'cnn') !== false) return '#CC0000';
    if (stripos($nome, 'bbc') !== false) return '#BB1919';
    if (stripos($nome, 'jovem pan') !== false) return '#D92828';
    if (stripos($nome, 'estadao') !== false) return '#193975';
    if (stripos($nome, 'infomoney') !== false) return '#003865';
    if (stripos($nome, 'tecmundo') !== false) return '#0587D6';
    if (stripos($nome, 'olhar digital') !== false) return '#573FA1';
    if (stripos($nome, 'canaltech') !== false) return '#E2231A';
    if (stripos($nome, 'espn') !== false) return '#CD112C';
    if (stripos($nome, 'gazeta') !== false) return '#F58220';
    if (stripos($nome, 'nexo') !== false) return '#111111';
    return '#E50914';
}

$rawNews = [];
$genericas = ["https://images.unsplash.com/photo-1495020689067-958852a7765e?w=1600","https://images.unsplash.com/photo-1557683316-973673baf926?w=1600"];
shuffle($genericas); $idxG = 0;
$ctx = stream_context_create(["ssl"=>["verify_peer"=>false,"verify_peer_name"=>false]]);

foreach ($rssSources as $url) {
    if(empty(trim($url))) continue;
    $xmlContent = @file_get_contents($url, false, $ctx);
    if ($xmlContent) {
        $xml = @simplexml_load_string($xmlContent);
        if ($xml) {
            $fonte = substr((string)$xml->channel->title, 0, 25);
            $corBadge = obterCorFonte($fonte);
            $ns = $xml->getNamespaces(true);
            $c = 0;
            foreach ($xml->channel->item as $item) {
                if ($c >= 4) break;
                $tit = (string)$item->title;
                $desc = strip_tags((string)$item->description);
                if (strlen($desc) > 280) $desc = substr($desc, 0, 280) . '...';
                $img = '';
                if (isset($ns['media']) && isset($item->children($ns['media'])->content->attributes()->url)) {
                    $img = (string)$item->children($ns['media'])->content->attributes()->url;
                }
                if (empty($img)) $img = obterImagemContexto($tit . ' ' . $desc);
                if (empty($img)) { $img = $genericas[$idxG]; $idxG++; if($idxG >= count($genericas)) $idxG = 0; }
                $rawNews[] = ['type'=>'news', 'dur'=>$tempoNoticia, 'content'=>['tit'=>$tit, 'desc'=>$desc, 'img'=>$img, 'src'=>$fonte, 'color'=>$corBadge]];
                $c++;
            }
        }
    }
}
shuffle($rawNews);
$rawNews = array_slice($rawNews, 0, $maxTotal);

$playlist = [];
$totalAds = count($ads);
$adIndex = 0;
$newsCounter = 0;

if ($totalAds == 0) {
    $playlist = $rawNews;
} else {
    usort($ads, function($a, $b) {
        $oa = isset($a['ordem']) ? $a['ordem'] : 999; $ob = isset($b['ordem']) ? $b['ordem'] : 999; return $oa <=> $ob;
    });
    foreach ($rawNews as $news) {
        $playlist[] = $news;
        $newsCounter++;
        if ($newsCounter % $frequenciaAds == 0) {
            $ad = $ads[$adIndex % $totalAds];
            $path = 'uploads/' . $ad['arquivo'];
            if (file_exists($path)) {
                $d = isset($ad['duracao']) ? $ad['duracao']*1000 : 10000;
                $playlist[] = ['type'=>'ad', 'media'=>$ad['tipo'], 'dur'=>$d, 'url'=>$path.'?v='.time()];
                $adIndex++;
            }
        }
    }
}
if (empty($playlist)) $playlist[] = ['type'=>'news', 'dur'=>10000, 'content'=>['tit'=>'Aguardando','desc'=>'Verifique configurações','img'=>$genericas[0],'src'=>'Sistema', 'color'=>'#333']];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloTv; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #000; font-family: 'Segoe UI', sans-serif; overflow: hidden; height: 100vh; width: 100vw; color: white; }
        #app { width: 100%; height: 100%; position: relative; }
        .slide { position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; visibility: hidden; transition: opacity 0.8s ease-in-out; z-index: 1; background: black; display: flex; justify-content: center; align-items: center; }
        .slide.active { opacity: 1; visibility: visible; z-index: 5; }
        .news-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; filter: brightness(0.35); transform: scale(1); animation: zoomEffect 20s linear forwards; }
        @keyframes zoomEffect { to { transform: scale(1.15); } }
        .news-container { position: absolute; bottom: 0; left: 0; width: 100%; padding: 5% 6%; z-index: 10; background: linear-gradient(to top, rgba(0,0,0,0.95) 10%, rgba(0,0,0,0.5) 60%, transparent 100%); }
        .badge { color: white; padding: 6px 14px; font-weight: 700; text-transform: uppercase; border-radius: 4px; display: inline-block; margin-bottom: 15px; font-size: clamp(12px, 1.8vw, 24px); box-shadow: 0 2px 10px rgba(0,0,0,0.5); }
        .title { font-size: clamp(24px, 4.5vw, 65px); font-weight: 800; line-height: 1.15; margin-bottom: 20px; text-shadow: 2px 2px 10px rgba(0,0,0,0.8); display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
        .desc { font-size: clamp(16px, 2.5vw, 36px); color: #e0e0e0; border-left: 5px solid #E50914; padding-left: 20px; line-height: 1.4; max-width: 90%; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
        .ad-media { width: 100%; height: 100%; object-fit: contain; background-color: #000; }
        .slide[data-type="ad"] img, .slide[data-type="ad"] video { filter: none !important; animation: none !important; }
        .header { position: absolute; top: 0; left: 0; width: 100%; padding: 3vh 5vw; display: flex; justify-content: space-between; align-items: center; z-index: 20; background: linear-gradient(to bottom, rgba(0,0,0,0.8), transparent); }
        .tv-name { font-size: clamp(18px, 3vh, 40px); font-weight: bold; text-transform: uppercase; letter-spacing: 1px; }
        .tv-clock { font-size: clamp(22px, 3.5vh, 45px); font-weight: bold; }
        @media (max-aspect-ratio: 1/1) { .news-container { padding-bottom: 10vh; } .title { -webkit-line-clamp: 4; } .desc { display: none; } }
    </style>
</head>
<body>
    <div class="header">
        <div class="tv-name"><?php echo $tituloTv; ?></div>
        <div class="tv-clock" id="relogio">--:--</div>
    </div>
    <div id="app">
        <?php foreach ($playlist as $i => $item): ?>
            <div class="slide" data-type="<?php echo $item['type']; ?>" data-media="<?php echo isset($item['media']) ? $item['media'] : ''; ?>" data-dur="<?php echo $item['dur']; ?>">
                <?php if ($item['type'] == 'news'): ?>
                    <img src="<?php echo $item['content']['img']; ?>" class="news-bg" onerror="this.src='<?php echo $genericas[0]; ?>'">
                    <div class="news-container">
                        <span class="badge" style="background-color: <?php echo isset($item['content']['color']) ? $item['content']['color'] : '#E50914'; ?>;">
                            <?php echo $item['content']['src']; ?>
                        </span>
                        <h1 class="title"><?php echo $item['content']['tit']; ?></h1>
                        <p class="desc" style="border-left-color: <?php echo isset($item['content']['color']) ? $item['content']['color'] : '#E50914'; ?>;">
                            <?php echo $item['content']['desc']; ?>
                        </p>
                    </div>
                <?php elseif ($item['type'] == 'ad'): ?>
                    <?php if ($item['media'] == 'video'): ?>
                        <video src="<?php echo $item['url']; ?>" class="ad-media" muted playsinline></video>
                    <?php else: ?>
                        <img src="<?php echo $item['url']; ?>" class="ad-media">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <script>
        let currentVersion = <?php echo $lastUpdate; ?>;
        const slides = document.querySelectorAll('.slide');
        let curr = 0; let timer;
        function run() {
            if(!slides.length) return;
            const s = slides[curr];
            const type = s.dataset.type;
            const media = s.dataset.media;
            const duration = parseInt(s.dataset.dur) || 10000;
            if (type === 'news' || (type === 'ad' && media === 'imagem')) {
                timer = setTimeout(next, duration);
            } 
            else if (type === 'ad' && media === 'video') {
                const vid = s.querySelector('video');
                if(vid) {
                    vid.currentTime = 0;
                    vid.play().catch(e => { next(); });
                    vid.onended = next;
                } else { timer = setTimeout(next, 5000); }
            }
        }
        function next() {
            clearTimeout(timer);
            const prevVid = slides[curr].querySelector('video'); if(prevVid) prevVid.pause();
            slides[curr].classList.remove('active');
            curr = (curr + 1) % slides.length;
            slides[curr].classList.add('active');
            run();
        }
        setInterval(() => { document.getElementById('relogio').innerText = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}); }, 1000);
        setInterval(() => {
            fetch('config.json?nocache=' + Date.now())
                .then(response => response.json())
                .then(data => {
                    if (data.last_update && data.last_update > currentVersion) { window.location.reload(); }
                })
                .catch(err => console.log(err));
        }, 5000);
        setTimeout(() => window.location.reload(), 1800000);
        if(slides.length > 0) { slides[0].classList.add('active'); run(); }
    </script>
</body>
</html>