<?php
// --- CONFIGURAÇÕES DO SISTEMA ---
ini_set('display_errors', 0); // Ocultar erros na tela da TV
error_reporting(E_ALL);
date_default_timezone_set('America/Sao_Paulo'); 

$configFile = 'config.json';
$cacheFile = 'cache_news.json';
$pastaUploads = 'uploads/';

// --- VERIFICAÇÃO INICIAL ---
if (!file_exists($configFile)) {
    die("
    <div style='height:100vh; display:flex; justify-content:center; align-items:center; background:#111; color:#fff; font-family:sans-serif; text-align:center;'>
        <div>
            <h1 style='color:#e74c3c'>Sistema não configurado</h1>
            <p>Acesse o <strong>admin.php</strong> para salvar as primeiras configurações.</p>
        </div>
    </div>");
}

$config = json_decode(file_get_contents($configFile), true);

// Recupera dados do JSON ou usa padrões
$tituloTv      = $config['titulo_tv'] ?? "TV Corporativa";
$tempoSlide    = ($config['tempo_slide'] ?? 15) * 1000; // Converte para ms
$maxNoticias   = $config['max_noticias_total'] ?? 20;
$rssSources    = $config['rss_sources'] ?? [];
$ads           = $config['ads'] ?? [];
$freqAds       = $config['frequencia_ads'] ?? 2;
$lastUpdate    = $config['last_update'] ?? time();

// --- FUNÇÕES AUXILIARES ---

// Define cor da tarja baseada no nome da fonte
function obterCorFonte($nome) {
    $nome = mb_strtolower($nome, 'UTF-8');
    $cores = [
        'g1' => '#C4170C', 'globo' => '#C4170C', 'uol' => '#F9A01B', 
        'cnn' => '#CC0000', 'bbc' => '#BB1919', 'folha' => '#004D8C',
        'estadao' => '#193975', 'tecmundo' => '#0587D6', 'espn' => '#CD112C',
        'ge' => '#06AA48', 'infomoney' => '#003865', 'forbes' => '#333333'
    ];
    foreach ($cores as $key => $cor) {
        if (stripos($nome, $key) !== false) return $cor;
    }
    return '#E50914'; // Cor padrão (Vermelho)
}

function fetchUrl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5); // Timeout rápido
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (TV Corporativa)');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

// --- PROCESSAMENTO DE NOTÍCIAS (CACHE) ---
$noticias = [];
$usarCache = false;

// Verifica se o cache é válido (10 minutos)
if (file_exists($cacheFile)) {
    if ((time() - filemtime($cacheFile)) < 600) {
        $conteudoCache = json_decode(file_get_contents($cacheFile), true);
        if (!empty($conteudoCache)) {
            $noticias = $conteudoCache;
            $usarCache = true;
        }
    }
}

// Se não usou cache, baixa RSS
if (!$usarCache && !empty($rssSources)) {
    foreach ($rssSources as $url) {
        if(empty(trim($url))) continue;
        $xmlContent = fetchUrl($url);
        
        if ($xmlContent) {
            $xml = @simplexml_load_string($xmlContent, 'SimpleXMLElement', LIBXML_NOCDATA);
            if ($xml) {
                $fonteTitle = mb_substr((string)$xml->channel->title, 0, 25);
                $corBadge = obterCorFonte($fonteTitle);
                $namespaces = $xml->getNamespaces(true);
                
                $count = 0;
                foreach ($xml->channel->item as $item) {
                    if ($count >= 4) break; // Max 4 notícias por fonte para variar
                    
                    $tit = trim((string)$item->title);
                    $desc = strip_tags(trim((string)$item->description));
                    // Limpa descrição
                    $desc = preg_replace('/\s+/', ' ', $desc);
                    if (mb_strlen($desc) > 200) $desc = mb_substr($desc, 0, 200) . '...';

                    // Tenta achar imagem (Media RSS, Enclosure ou tag img na descrição)
                    $img = '';
                    if (isset($namespaces['media']) && isset($item->children($namespaces['media'])->content)) {
                        $attr = $item->children($namespaces['media'])->content->attributes();
                        $img = (string)$attr->url;
                    } elseif (isset($item->enclosure)) {
                        $img = (string)$item->enclosure['url'];
                    }
                    if (empty($img)) {
                        preg_match('/<img.+src=[\'"](?P<src>.+?)[\'"].*>/i', (string)$item->description, $match);
                        if(isset($match['src'])) $img = $match['src'];
                    }

                    $noticias[] = [
                        'tipo' => 'noticia',
                        'duracao' => $tempoSlide,
                        'conteudo' => [
                            'titulo' => $tit,
                            'descricao' => $desc,
                            'imagem' => $img,
                            'fonte' => $fonteTitle,
                            'cor' => $corBadge
                        ]
                    ];
                    $count++;
                }
            }
        }
    }
    // Salva cache se encontrou notícias
    if (!empty($noticias)) {
        file_put_contents($cacheFile, json_encode($noticias));
    }
}

// Recupera do cache se falhou o download
if (empty($noticias) && file_exists($cacheFile)) {
    $noticias = json_decode(file_get_contents($cacheFile), true);
}

// Embaralha e limita
shuffle($noticias);
$noticias = array_slice($noticias, 0, $maxNoticias);

// Adiciona gradientes aleatórios nas notícias
$gradientes = [
    'linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d)',
    'linear-gradient(135deg, #0f2027, #203a43, #2c5364)',
    'linear-gradient(135deg, #114357, #F29492)',
    'linear-gradient(135deg, #000428, #004e92)',
    'linear-gradient(135deg, #4568dc, #b06ab3)'
];
foreach($noticias as $k => $v) {
    $noticias[$k]['conteudo']['bg'] = $gradientes[array_rand($gradientes)];
}

// --- MONTAGEM DA PLAYLIST (MISTURA ADS E NOTÍCIAS) ---
$playlist = [];
$totalAds = count($ads);
$adIndex = 0;
$newsCounter = 0;

// Ordena Ads pela ordem definida no admin
usort($ads, function($a, $b) {
    return ($a['ordem'] ?? 99) <=> ($b['ordem'] ?? 99);
});

if ($totalAds > 0 && !empty($noticias)) {
    foreach ($noticias as $news) {
        $playlist[] = $news;
        $newsCounter++;
        
        // Insere Ad a cada X notícias
        if ($newsCounter % $freqAds == 0) {
            $adAtual = $ads[$adIndex % $totalAds];
            $caminhoAd = $pastaUploads . $adAtual['arquivo'];
            
            if (file_exists($caminhoAd)) {
                // Se for vídeo, duração é controlada pelo JS, mas passamos um fallback
                // Se for imagem, usa a duração configurada no admin ou padrão
                $duracaoAd = ($adAtual['duracao'] > 0) ? $adAtual['duracao'] * 1000 : 10000;
                
                $playlist[] = [
                    'tipo' => 'ad',
                    'midia_tipo' => $adAtual['tipo'], // 'imagem' ou 'video'
                    'duracao' => $duracaoAd,
                    'url' => $caminhoAd . '?v=' . time() // Cache buster
                ];
                $adIndex++;
            }
        }
    }
} elseif ($totalAds > 0) {
    // Só tem ads
    foreach ($ads as $ad) {
        $playlist[] = [
            'tipo' => 'ad',
            'midia_tipo' => $ad['tipo'],
            'duracao' => ($ad['duracao'] > 0) ? $ad['duracao'] * 1000 : 10000,
            'url' => $pastaUploads . $ad['arquivo']
        ];
    }
} else {
    // Só tem notícias
    $playlist = $noticias;
}

// Fallback se tudo estiver vazio
if (empty($playlist)) {
    $playlist[] = [
        'tipo' => 'noticia',
        'duracao' => 10000,
        'conteudo' => [
            'titulo' => 'Bem-vindo à TV Corporativa',
            'descricao' => 'Aguardando configuração de conteúdo...',
            'imagem' => '',
            'fonte' => 'Sistema',
            'cor' => '#333',
            'bg' => 'linear-gradient(to right, #232526, #414345)'
        ]
    ];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloTv; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700;900&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #E50914; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #000; font-family: 'Roboto', sans-serif; overflow: hidden; width: 100vw; height: 100vh; color: white; cursor: none; }
        
        #tv-container { width: 100%; height: 100%; position: relative; background: #000; }
        
        /* HEADER FIXO */
        .header { 
            position: absolute; top: 0; left: 0; width: 100%; height: 14vh;
            padding: 0 4vw; display: flex; justify-content: space-between; align-items: center; 
            z-index: 50; 
            background: linear-gradient(to bottom, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0) 100%); 
        }
        .brand h1 { font-size: 2.5vh; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; color: rgba(255,255,255,0.9); }
        .brand p { font-size: 1.8vh; font-weight: 300; color: #ccc; text-transform: capitalize; }
        .clock { font-size: 5vh; font-weight: 700; text-shadow: 2px 2px 5px rgba(0,0,0,0.5); font-feature-settings: "tnum"; font-variant-numeric: tabular-nums; }

        /* SLIDES */
        .slide { 
            position: absolute; top: 0; left: 0; width: 100%; height: 100%; 
            opacity: 0; visibility: hidden; transition: opacity 1s ease; 
            z-index: 10; background: #000; 
        }
        .slide.active { opacity: 1; visibility: visible; z-index: 20; }
        
        /* IMAGEM E FUNDO */
        .bg-img, .bg-video { 
            position: absolute; top: 0; left: 0; width: 100%; height: 100%; 
            object-fit: cover; 
        }
        .slide[data-type="noticia"] .bg-img { filter: brightness(0.4); transform: scale(1); }
        .slide.active[data-type="noticia"] .bg-img.zoom { animation: zoomSlow 20s linear forwards; }
        
        .solid-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; }

        /* CONTEÚDO DA NOTÍCIA */
        .news-content { 
            position: absolute; bottom: 0; left: 0; width: 100%; 
            padding: 5vh 5vw 8vh 5vw; z-index: 30;
            background: linear-gradient(to top, rgba(0,0,0,1) 10%, transparent 100%);
        }
        .source-badge { 
            display: inline-block; padding: 0.8vh 2vh; border-radius: 4px; 
            font-weight: 900; text-transform: uppercase; letter-spacing: 1px; font-size: 1.8vh;
            margin-bottom: 2vh; box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        }
        .news-title { 
            font-size: 6vh; line-height: 1.1; font-weight: 900; margin-bottom: 2vh; 
            text-shadow: 0 2px 10px rgba(0,0,0,0.8);
            display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
        }
        .news-desc { 
            font-size: 3vh; line-height: 1.4; font-weight: 300; color: #ddd;
            border-left: 5px solid var(--primary); padding-left: 2vh; max-width: 90%;
            display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
        }

        /* ADS FULLSCREEN */
        .slide[data-type="ad"] .bg-img, .slide[data-type="ad"] .bg-video {
            object-fit: contain; /* Ajusta para caber na tela sem cortar */
            background: #000;
        }
        
        @keyframes zoomSlow { from { transform: scale(1); } to { transform: scale(1.1); } }
    </style>
</head>
<body>

    <div class="header">
        <div class="brand">
            <h1><?php echo htmlspecialchars($tituloTv); ?></h1>
            <p id="data-display">Carregando...</p>
        </div>
        <div class="clock" id="relogio">00:00</div>
    </div>

    <div id="tv-container">
        <?php foreach ($playlist as $i => $item): ?>
            <div class="slide" 
                 data-index="<?php echo $i; ?>" 
                 data-type="<?php echo $item['tipo']; ?>" 
                 data-media="<?php echo isset($item['midia_tipo']) ? $item['midia_tipo'] : ''; ?>" 
                 data-dur="<?php echo $item['duracao']; ?>">
                
                <?php if ($item['tipo'] == 'noticia'): ?>
                    <!-- NOTÍCIA -->
                    <?php if (!empty($item['conteudo']['imagem'])): ?>
                        <img src="<?php echo $item['conteudo']['imagem']; ?>" class="bg-img zoom" onerror="this.style.display='none'">
                    <?php endif; ?>
                    <div class="solid-bg" style="background: <?php echo $item['conteudo']['bg']; ?>;"></div>

                    <div class="news-content">
                        <span class="source-badge" style="background: <?php echo $item['conteudo']['cor']; ?>;">
                            <?php echo $item['conteudo']['fonte']; ?>
                        </span>
                        <h2 class="news-title"><?php echo $item['conteudo']['titulo']; ?></h2>
                        <p class="news-desc" style="border-color: <?php echo $item['conteudo']['cor']; ?>;">
                            <?php echo $item['conteudo']['descricao']; ?>
                        </p>
                    </div>

                <?php elseif ($item['tipo'] == 'ad'): ?>
                    <!-- PROPAGANDA -->
                    <?php if ($item['midia_tipo'] == 'video'): ?>
                        <video src="<?php echo $item['url']; ?>" class="bg-video" muted playsinline></video>
                    <?php else: ?>
                        <img src="<?php echo $item['url']; ?>" class="bg-img">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        const configVersion = <?php echo $lastUpdate; ?>;
        const slides = document.querySelectorAll('.slide');
        let currentSlide = 0;
        let slideTimer;

        // --- RELÓGIO ---
        function updateClock() {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
            document.getElementById('relogio').textContent = timeStr;
            
            const dateStr = now.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
            document.getElementById('data-display').textContent = dateStr;
        }
        setInterval(updateClock, 1000);
        updateClock();

        // --- MOTOR DA PLAYLIST ---
        function playSlide() {
            if (slides.length === 0) return;

            const slide = slides[currentSlide];
            const type = slide.dataset.type;
            const mediaType = slide.dataset.media;
            let duration = parseInt(slide.dataset.dur) || 10000;

            // Ativar slide visualmente
            slide.classList.add('active');

            // Lógica Específica
            if (type === 'ad' && mediaType === 'video') {
                const video = slide.querySelector('video');
                if (video) {
                    video.currentTime = 0;
                    video.play().then(() => {
                        // Se o vídeo tiver duração válida, usa ela. Senão usa o fallback.
                        if (video.duration && !isNaN(video.duration) && video.duration > 1) {
                            duration = video.duration * 1000; 
                        }
                        // Define o tempo baseado na duração do vídeo
                        slideTimer = setTimeout(nextSlide, duration);
                        // Backup caso onended falhe ou calculo esteja errado
                        video.onended = () => { clearTimeout(slideTimer); nextSlide(); };
                    }).catch(err => {
                        console.error("Erro autoplay:", err);
                        slideTimer = setTimeout(nextSlide, 5000);
                    });
                } else {
                    slideTimer = setTimeout(nextSlide, duration);
                }
            } else {
                // Notícias e Imagens
                slideTimer = setTimeout(nextSlide, duration);
            }
        }

        function nextSlide() {
            clearTimeout(slideTimer);
            
            // Pausa vídeo anterior se houver
            const prev = slides[currentSlide];
            const prevVideo = prev.querySelector('video');
            if (prevVideo) { prevVideo.pause(); prevVideo.currentTime = 0; }
            
            prev.classList.remove('active');
            
            // Próximo índice
            currentSlide = (currentSlide + 1) % slides.length;
            
            playSlide();
        }

        // --- VERIFICAÇÃO DE ATUALIZAÇÃO (AUTO-RELOAD) ---
        // Checa a cada 10 segundos se o admin salvou algo novo
        setInterval(() => {
            fetch('config.json?nocache=' + Date.now())
                .then(response => response.json())
                .then(data => {
                    if (data.last_update && data.last_update > configVersion) {
                        console.log("Nova configuração detectada. Atualizando...");
                        window.location.reload();
                    }
                })
                .catch(e => console.log("Erro ao checar update"));
        }, 10000);

        // Recarrega a página inteira a cada 30 minutos para limpar memória/cache
        setTimeout(() => window.location.reload(), 1800000);

        // Inicia
        if(slides.length > 0) playSlide();

    </script>
</body>
</html>