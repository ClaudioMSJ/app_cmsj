<?php
// =================================================================================
// BLOCO 1: VERIFICADOR DE ATUALIZAÇÕES (MÉTODO INSTALADOR EXTERNO)
// =================================================================================
set_time_limit(300);
ini_set('display_errors', 0); 
error_reporting(E_ALL);
date_default_timezone_set('America/Sao_Paulo'); 

// Configurações do Update
$urlDownload     = 'https://cdn.jsdelivr.net/gh/ClaudioMSJ/app_cmsj@main/tv.zip';
$urlApiCheck     = 'https://api.github.com/repos/ClaudioMSJ/app_cmsj/commits/main';
$arquivoZip      = 'tv.zip';
$arquivoVersao   = 'versao_instalada.txt';
$scriptAtualizador = 'atualizador_temp.php';

// Verificação (Evita rodar a cada reload, roda se não tiver flag de sessão ou timer)
// Para simplificar, vamos checar sempre que carregar, mas com timeout curto.
$chApi = curl_init($urlApiCheck);
curl_setopt($chApi, CURLOPT_RETURNTRANSFER, true);
curl_setopt($chApi, CURLOPT_USERAGENT, 'Monitor-Update-App'); 
curl_setopt($chApi, CURLOPT_TIMEOUT, 3); // 3 seg max para não travar
$respostaApi = curl_exec($chApi);
$httpCodeApi = curl_getinfo($chApi, CURLINFO_HTTP_CODE);
curl_close($chApi);

if ($httpCodeApi == 200) {
    $dadosApi = json_decode($respostaApi, true);
    
    if (isset($dadosApi['sha'])) {
        $novaVersao = $dadosApi['sha'];
        $versaoAtual = file_exists($arquivoVersao) ? file_get_contents($arquivoVersao) : '';

        if ($novaVersao !== $versaoAtual) {
            // 1. BAIXAR O ZIP
            $fp = fopen($arquivoZip, 'w+');
            $ch = curl_init($urlDownload);
            curl_setopt($ch, CURLOPT_FILE, $fp);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
            $exec = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            fclose($fp);

            if ($exec && $httpCode == 200) {
                // 2. CRIAR O SCRIPT ATUALIZADOR TEMPORÁRIO
                // Este script vai rodar FORA do index.php para poder sobrescrevê-lo
                $conteudoAtualizador = '<?php
                // Script gerado automaticamente para aplicar update
                set_time_limit(60);
                
                // Aguarda 2 segundos para garantir que o index.php liberou o arquivo
                sleep(2);
                
                $zip = new ZipArchive;
                if ($zip->open("'.$arquivoZip.'") === TRUE) {
                    // Extrai sobrescrevendo tudo
                    $zip->extractTo(__DIR__);
                    $zip->close();
                    
                    // Atualiza a versão
                    file_put_contents("'.$arquivoVersao.'", "'.$novaVersao.'");
                    
                    // Limpa bagunça
                    @unlink("'.$arquivoZip.'");
                    
                    // Limpa Cache OPcode (Crucial)
                    if (function_exists("opcache_reset")) { opcache_reset(); }
                    
                    echo "<div style=\'font-family:sans-serif; text-align:center; padding:50px;\'>";
                    echo "<h1>Atualização Concluída!</h1>";
                    echo "<p>Redirecionando...</p>";
                    echo "<script>setTimeout(function(){ window.location.href = \'index.php\'; }, 1000);</script>";
                    echo "</div>";
                } else {
                    echo "Erro ao extrair o ZIP.";
                }
                
                // O script se autodestrói no final
                @unlink(__FILE__);
                ?>';

                file_put_contents($scriptAtualizador, $conteudoAtualizador);

                // 3. REDIRECIONAR PARA O ATUALIZADOR E ENCERRAR ESTE SCRIPT
                header("Location: $scriptAtualizador");
                exit;
            }
        }
    }
}

// =================================================================================
// BLOCO 2: APLICAÇÃO TV CORPORATIVA
// =================================================================================

$configFile = 'config.json';
// Cria config padrão se não existir para evitar erro fatal na primeira vez
if (!file_exists($configFile)) {
    $defaultConfig = [
        "last_update" => time(),
        "titulo_tv" => "TV Corporativa",
        "rss_sources" => ["https://g1.globo.com/rss/g1/", "https://rss.tecmundo.com.br/feed"],
        "tempo_slide" => 15
    ];
    file_put_contents($configFile, json_encode($defaultConfig));
}

$config = json_decode(file_get_contents($configFile), true);
if (!$config) $config = []; // Fallback

$lastUpdate = $config['last_update'] ?? time();

// Configurações Padrão
$rssSources    = $config['rss_sources'] ?? [];
$maxTotal      = $config['max_noticias_total'] ?? 20;
$tempoNoticia  = ($config['tempo_slide'] ?? 15) * 1000; 
$frequenciaAds = $config['frequencia_ads'] ?? 2;
$ads           = $config['ads'] ?? [];
$tituloTv      = $config['titulo_tv'] ?? "TV Corporativa";
$tempoCache    = 600; 

function obterCorFonte($nome) {
    $nome = mb_strtolower($nome, 'UTF-8');
    $cores = [
        'g1' => '#C4170C', 'uol' => '#F9A01B', 'folha' => '#004D8C', 
        'cnn' => '#CC0000', 'bbc' => '#BB1919', 'jovem pan' => '#D92828',
        'estadao' => '#193975', 'infomoney' => '#003865', 'tecmundo' => '#0587D6',
        'olhar' => '#573FA1', 'canaltech' => '#E2231A', 'espn' => '#CD112C',
        'nexo' => '#111111', 'forbes' => '#333333', 'exame' => '#000000'
    ];
    foreach ($cores as $key => $cor) {
        if (stripos($nome, $key) !== false) return $cor;
    }
    return '#E50914'; 
}

function fetchUrl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (TV Corporativa; PHP)');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

// --- SISTEMA DE CACHE DE NOTÍCIAS ---
$cacheFile = 'cache_news.json';
$rawNews = [];
$usarCache = false;

if (file_exists($cacheFile)) {
    $fileAge = time() - filemtime($cacheFile);
    if ($fileAge < $tempoCache) {
        $rawNews = json_decode(file_get_contents($cacheFile), true);
        if (!empty($rawNews)) $usarCache = true;
    }
}

if (!$usarCache) {
    foreach ($rssSources as $url) {
        if(empty(trim($url))) continue;
        $xmlContent = fetchUrl($url);
        if ($xmlContent) {
            $xml = @simplexml_load_string($xmlContent, 'SimpleXMLElement', LIBXML_NOCDATA);
            if ($xml) {
                $fonte = mb_substr((string)$xml->channel->title, 0, 30);
                $corBadge = obterCorFonte($fonte);
                $ns = $xml->getNamespaces(true);
                $c = 0;
                foreach ($xml->channel->item as $item) {
                    if ($c >= 4) break; 
                    
                    $tit = trim((string)$item->title);
                    $desc = strip_tags(trim((string)$item->description));
                    $desc = preg_replace('/\s+/', ' ', $desc); 
                    if (mb_strlen($desc) > 240) $desc = mb_substr($desc, 0, 240) . '...';

                    $img = '';
                    if (isset($ns['media']) && isset($item->children($ns['media'])->content)) {
                        $attr = $item->children($ns['media'])->content->attributes();
                        $img = (string)$attr->url;
                    } elseif (isset($item->enclosure)) {
                        $img = (string)$item->enclosure['url'];
                    }
                    if (empty($img)) {
                        preg_match('/<img.+src=[\'"](?P<src>.+?)[\'"].*>/i', (string)$item->description, $image);
                        if(isset($image['src'])) $img = $image['src'];
                    }

                    $rawNews[] = [
                        'type'=>'news', 
                        'dur'=>$tempoNoticia, 
                        'content'=>[
                            'tit'=>$tit, 
                            'desc'=>$desc, 
                            'img'=>$img,
                            'src'=>$fonte, 
                            'color'=>$corBadge
                        ]
                    ];
                    $c++;
                }
            }
        }
    }
    if (!empty($rawNews)) {
        file_put_contents($cacheFile, json_encode($rawNews));
    }
}

if(empty($rawNews) && file_exists($cacheFile)){
    $rawNews = json_decode(file_get_contents($cacheFile), true);
}
if (!is_array($rawNews)) $rawNews = [];

shuffle($rawNews);
$rawNews = array_slice($rawNews, 0, $maxTotal);

$bgGradients = [
    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'linear-gradient(135deg, #232526 0%, #414345 100%)',
    'linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)',
    'linear-gradient(135deg, #373B44 0%, #4286f4 100%)',
    'linear-gradient(135deg, #8E2DE2 0%, #4A00E0 100%)',
    'linear-gradient(135deg, #b92b27 0%, #1565C0 100%)'
];

$lastG = -1;
foreach($rawNews as $k => $v){
    do { $idx = array_rand($bgGradients); } while ($idx === $lastG);
    $lastG = $idx;
    $rawNews[$k]['content']['bg_gradient'] = $bgGradients[$idx];
}

$playlist = [];
$totalAds = count($ads);
$adIndex = 0;
$newsCounter = 0;

if ($totalAds > 0) {
    usort($ads, function($a, $b) { return ($a['ordem'] ?? 99) <=> ($b['ordem'] ?? 99); });
    foreach ($rawNews as $news) {
        $playlist[] = $news;
        $newsCounter++;
        if ($newsCounter % $frequenciaAds == 0) {
            $ad = $ads[$adIndex % $totalAds];
            $path = 'uploads/' . $ad['arquivo'];
            if (file_exists($path)) {
                $d = isset($ad['duracao']) && $ad['duracao'] > 0 ? $ad['duracao']*1000 : 10000;
                $playlist[] = ['type'=>'ad', 'media'=>$ad['tipo'], 'dur'=>$d, 'url'=>$path.'?v='.time()];
                $adIndex++;
            }
        }
    }
} else {
    $playlist = $rawNews;
}

if (empty($playlist)) $playlist[] = ['type'=>'news', 'dur'=>10000, 'content'=>['tit'=>'Bem-vindo', 'desc'=>'Inicializando sistema de notícias...', 'img'=>'', 'bg_gradient'=>$bgGradients[0], 'src'=>'Sistema', 'color'=>'#555']];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloTv; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700;900&display=swap" rel="stylesheet">
    <style>
        :root { --primary-color: #E50914; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #000; font-family: 'Roboto', sans-serif; overflow: hidden; height: 100vh; width: 100vw; color: white; cursor: none; }
        
        #app { width: 100%; height: 100%; position: relative; background: #111; }
        
        .header { 
            position: absolute; top: 0; left: 0; width: 100%; height: 15vh;
            padding: 0 5vw; display: flex; justify-content: space-between; align-items: center; 
            z-index: 20; 
            background: linear-gradient(to bottom, rgba(0,0,0,0.9), transparent); 
        }
        .tv-info { display: flex; flex-direction: column; }
        .tv-name { font-size: clamp(18px, 2vw, 30px); font-weight: 900; text-transform: uppercase; letter-spacing: 2px; color: rgba(255,255,255,0.8); }
        .tv-date { font-size: clamp(14px, 1.2vw, 20px); font-weight: 300; color: #ddd; margin-top: 5px; text-transform: capitalize; }
        .tv-clock { font-size: clamp(30px, 4vw, 60px); font-weight: 700; text-shadow: 2px 2px 10px rgba(0,0,0,0.5); letter-spacing: -1px; }

        .slide { 
            position: absolute; top: 0; left: 0; width: 100%; height: 100%; 
            opacity: 0; visibility: hidden; transition: opacity 1s ease-in-out; 
            z-index: 1; background: black; overflow: hidden;
        }
        .slide.active { opacity: 1; visibility: visible; z-index: 5; }
        
        .bg-media { 
            position: absolute; top: 0; left: 0; width: 100%; height: 100%; 
            object-fit: cover; filter: brightness(0.4); 
            transform: scale(1); 
        }
        .slide.active .bg-media.zoom { animation: zoomEffect 25s linear forwards; }
        .slide[data-type="ad"] .bg-media { filter: none; object-fit: contain; background: black; animation: none; }
        .solid-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }

        @keyframes zoomEffect { from { transform: scale(1); } to { transform: scale(1.15); } }
        
        .content-box { 
            position: absolute; bottom: 0; left: 0; width: 100%; 
            padding: 6vh 5vw 8vh 5vw; z-index: 10; 
            background: linear-gradient(to top, rgba(0,0,0,1) 0%, rgba(0,0,0,0.8) 40%, transparent 100%); 
        }
        
        .badge { 
            background: var(--primary-color); color: white; 
            padding: 5px 12px; font-weight: 700; text-transform: uppercase; 
            border-radius: 3px; display: inline-block; margin-bottom: 2vh; 
            font-size: clamp(12px, 1.2vw, 18px); letter-spacing: 1px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }
        
        .title { 
            font-size: clamp(28px, 4.5vw, 70px); font-weight: 900; 
            line-height: 1.1; margin-bottom: 2vh; color: #fff;
            text-shadow: 0 2px 10px rgba(0,0,0,0.8);
            display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
        }
        
        .desc { 
            font-size: clamp(18px, 2.2vw, 32px); color: #ccc; 
            font-weight: 300; line-height: 1.4; max-width: 90%;
            border-left: 4px solid var(--primary-color); padding-left: 20px;
            display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
        }

        video::-webkit-media-controls { display:none !important; }
    </style>
</head>
<body>

    <div class="header">
        <div class="tv-info">
            <div class="tv-name"><?php echo $tituloTv; ?></div>
            <div class="tv-date" id="data-extensa">...</div>
        </div>
        <div class="tv-clock" id="relogio">--:--</div>
    </div>

    <div id="app">
        <?php foreach ($playlist as $i => $item): ?>
            <div class="slide" data-index="<?php echo $i; ?>" data-type="<?php echo $item['type']; ?>" data-media="<?php echo isset($item['media']) ? $item['media'] : ''; ?>" data-dur="<?php echo $item['dur']; ?>">
                
                <?php if ($item['type'] == 'news'): ?>
                    <div class="bg-wrapper" style="width:100%; height:100%; position:absolute; top:0; left:0;">
                        <?php if (!empty($item['content']['img'])): ?>
                            <img src="<?php echo $item['content']['img']; ?>" class="bg-media zoom" onerror="this.style.display='none'; this.parentElement.querySelector('.solid-bg').style.display='block';">
                            <div class="solid-bg" style="background: <?php echo $item['content']['bg_gradient']; ?>; display:none;"></div>
                        <?php else: ?>
                            <div class="solid-bg" style="background: <?php echo $item['content']['bg_gradient']; ?>;"></div>
                        <?php endif; ?>
                    </div>

                    <div class="content-box">
                        <span class="badge" style="background-color: <?php echo isset($item['content']['color']) ? $item['content']['color'] : '#E50914'; ?>;">
                            <?php echo $item['content']['src']; ?>
                        </span>
                        <h1 class="title"><?php echo $item['content']['tit']; ?></h1>
                        <p class="desc" style="border-left-color: <?php echo isset($item['content']['color']) ? $item['content']['color'] : '#E50914'; ?>;">
                            <?php echo $item['content']['desc']; ?>
                        </p>
                    </div>

                <?php elseif ($item['type'] == 'ad'): ?>
                    <?php if ($item['media'] == 'video'): ?>
                        <video src="<?php echo $item['url']; ?>" class="bg-media" muted playsinline></video>
                    <?php else: ?>
                        <img src="<?php echo $item['url']; ?>" class="bg-media">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        const configVersion = <?php echo $lastUpdate; ?>;
        const slides = document.querySelectorAll('.slide');
        let curr = 0; 
        let timer;

        function updateClock() {
            const now = new Date();
            document.getElementById('relogio').innerText = now.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
            
            const options = { weekday: 'long', day: 'numeric', month: 'long' };
            document.getElementById('data-extensa').innerText = now.toLocaleDateString('pt-BR', options);
        }
        setInterval(updateClock, 1000);
        updateClock();

        function run() {
            if(!slides.length) return;
            const s = slides[curr];
            const type = s.dataset.type;
            const media = s.dataset.media;
            let duration = parseInt(s.dataset.dur) || 10000;

            const prevSlide = slides[(curr - 1 + slides.length) % slides.length];
            const prevVid = prevSlide.querySelector('video');
            if(prevVid) { prevVid.pause(); prevVid.currentTime = 0; }

            if (type === 'news' || (type === 'ad' && media === 'imagem')) {
                timer = setTimeout(next, duration);
            } 
            else if (type === 'ad' && media === 'video') {
                const vid = s.querySelector('video');
                if(vid) {
                    vid.currentTime = 0;
                    const playPromise = vid.play();
                    if (playPromise !== undefined) {
                        playPromise.then(_ => {
                            if(vid.duration && !isNaN(vid.duration) && vid.duration > 1) {
                                duration = vid.duration * 1000;
                            }
                            timer = setTimeout(next, duration + 500);
                            vid.onended = next;
                        })
                        .catch(error => {
                            console.warn("Autoplay erro:", error);
                            timer = setTimeout(next, 5000);
                        });
                    }
                } else {
                    timer = setTimeout(next, 5000);
                }
            }
        }

        function next() {
            clearTimeout(timer);
            slides[curr].classList.remove('active');
            curr = (curr + 1) % slides.length;
            slides[curr].classList.add('active');
            run();
        }

        setInterval(() => {
            fetch('config.json?nocache=' + Date.now())
                .then(r => r.json())
                .then(data => {
                    if (data.last_update && data.last_update > configVersion) {
                        window.location.reload();
                    }
                })
                .catch(e => {});
        }, 10000);

        setTimeout(() => window.location.reload(), 1800000);

        if(slides.length > 0) { 
            slides[0].classList.add('active'); 
            run(); 
        }
    </script>
</body>
</html>