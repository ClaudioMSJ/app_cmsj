<?php
// ... (Configurações padrão do PHP) ...
ini_set('display_errors', 0); error_reporting(E_ALL);
$configFile = 'config.json';
if (!file_exists($configFile)) die("Configure no admin.php");
$json = file_get_contents($configFile);
$config = json_decode($json, true);
if (!$config) die("Erro no JSON");

$lastUpdate = isset($config['last_update']) ? $config['last_update'] : time();

// Configurações Gerais
$rssSources = isset($config['rss_sources']) ? $config['rss_sources'] : [];
$maxTotal = isset($config['max_noticias_total']) ? $config['max_noticias_total'] : 20;
$tempoNoticia = (isset($config['tempo_slide']) ? $config['tempo_slide'] : 15) * 1000; 
$frequenciaAds = isset($config['frequencia_ads']) ? $config['frequencia_ads'] : 2;
$ads = isset($config['ads']) ? $config['ads'] : [];
$tituloTv = isset($config['titulo_tv']) ? $config['titulo_tv'] : "TV Corporativa";

// --- PALETA DE DEGRADÊS MODERNOS (Para notícias sem imagem) ---
$bgGradients = [
    'linear-gradient(135deg, #8E2DE2 0%, #4A00E0 100%)', // Roxo
    'linear-gradient(135deg, #c31432 0%, #240b36 100%)', // Vinho Escuro
    'linear-gradient(135deg, #00b09b 0%, #96c93d 100%)', // Verde
    'linear-gradient(135deg, #ff512f 0%, #dd2476 100%)', // Laranja/Rosa
    'linear-gradient(135deg, #2b5876 0%, #4e4376 100%)', // Azul Naval
    'linear-gradient(135deg, #f857a6 0%, #ff5858 100%)', // Rosa Avermelhado
    'linear-gradient(135deg, #16222A 0%, #3A6073 100%)', // Cinza/Azul Frio
    'linear-gradient(135deg, #1D976C 0%, #93F9B9 100%)', // Verde Água
    'linear-gradient(135deg, #EB3349 0%, #F45C43 100%)'  // Vermelho Vibrante
];

// --- FUNÇÃO: COR DA BADGE ---
function obterCorFonte($nome) {
    $nome = mb_strtolower($nome, 'UTF-8');
    if (stripos($nome, 'g1') !== false) return '#C4170C';
    if (stripos($nome, 'uol') !== false) return '#F9A01B';
    if (stripos($nome, 'folha') !== false) return '#004D8C';
    if (stripos($nome, 'cnn') !== false) return '#CC0000';
    if (stripos($nome, 'bbc') !== false) return '#BB1919';
    if (stripos($nome, 'jovem pan') !== false) return '#D92828';
    if (stripos($nome, 'estadao') !== false) return '#193975';
    if (stripos($nome, 'infomoney') !== false) return '#003865';
    if (stripos($nome, 'tecmundo') !== false) return '#0587D6';
    if (stripos($nome, 'olhar digital') !== false) return '#573FA1';
    if (stripos($nome, 'canaltech') !== false) return '#E2231A';
    if (stripos($nome, 'espn') !== false) return '#CD112C';
    if (stripos($nome, 'gazeta') !== false) return '#F58220';
    if (stripos($nome, 'nexo') !== false) return '#111111';
    return '#E50914'; 
}

$rawNews = [];
$ctx = stream_context_create(["ssl"=>["verify_peer"=>false,"verify_peer_name"=>false]]);

// 1. COLETA NOTÍCIAS
foreach ($rssSources as $url) {
    if(empty(trim($url))) continue;
    $xmlContent = @file_get_contents($url, false, $ctx);
    if ($xmlContent) {
        $xml = @simplexml_load_string($xmlContent);
        if ($xml) {
            $fonte = substr((string)$xml->channel->title, 0, 25);
            $corBadge = obterCorFonte($fonte);
            $ns = $xml->getNamespaces(true);
            $c = 0;
            foreach ($xml->channel->item as $item) {
                if ($c >= 4) break;
                $tit = (string)$item->title;
                $desc = strip_tags((string)$item->description);
                if (strlen($desc) > 280) $desc = substr($desc, 0, 280) . '...';
                
                // Tenta pegar imagem do RSS (e somente do RSS)
                $img = '';
                if (isset($ns['media']) && isset($item->children($ns['media'])->content->attributes()->url)) {
                    $img = (string)$item->children($ns['media'])->content->attributes()->url;
                }
                
                $rawNews[] = [
                    'type'=>'news', 
                    'dur'=>$tempoNoticia, 
                    'content'=>[
                        'tit'=>$tit, 
                        'desc'=>$desc, 
                        'img'=>$img, // Se vazio, vira cor lá embaixo
                        'src'=>$fonte, 
                        'color'=>$corBadge,
                        'bg_gradient' => '' 
                    ]
                ];
                $c++;
            }
        }
    }
}

// 2. EMBARALHA
shuffle($rawNews);
$rawNews = array_slice($rawNews, 0, $maxTotal);

// 3. APLICA CORES (Garante que não repete a mesma cor seguida)
$lastColorIdx = -1;
foreach ($rawNews as &$item) {
    // Se não tem imagem, define um gradiente
    if (empty($item['content']['img'])) {
        $attempts = 0;
        do {
            $idx = array_rand($bgGradients);
            $attempts++;
        } while ($idx === $lastColorIdx && $attempts < 10); // Tenta achar uma cor diferente da anterior
        
        $lastColorIdx = $idx;
        $item['content']['bg_gradient'] = $bgGradients[$idx];
    }
}
unset($item);

// 4. MONTA PLAYLIST (Intercala Ads)
$playlist = [];
$totalAds = count($ads);
$adIndex = 0;
$newsCounter = 0;

if ($totalAds == 0) {
    $playlist = $rawNews;
} else {
    usort($ads, function($a, $b) {
        $oa = isset($a['ordem']) ? $a['ordem'] : 999; $ob = isset($b['ordem']) ? $b['ordem'] : 999; return $oa <=> $ob;
    });
    foreach ($rawNews as $news) {
        $playlist[] = $news;
        $newsCounter++;
        if ($newsCounter % $frequenciaAds == 0) {
            $ad = $ads[$adIndex % $totalAds];
            $path = 'uploads/' . $ad['arquivo'];
            if (file_exists($path)) {
                $d = isset($ad['duracao']) ? $ad['duracao']*1000 : 10000;
                $playlist[] = ['type'=>'ad', 'media'=>$ad['tipo'], 'dur'=>$d, 'url'=>$path.'?v='.time()];
                $adIndex++;
            }
        }
    }
}

// Fallback
if (empty($playlist)) $playlist[] = ['type'=>'news', 'dur'=>10000, 'content'=>['tit'=>'Bem-vindo','desc'=>'Carregando informações...','img'=>'','bg_gradient'=>$bgGradients[0],'src'=>'Sistema', 'color'=>'#333']];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloTv; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #000; font-family: 'Segoe UI', sans-serif; overflow: hidden; height: 100vh; width: 100vw; color: white; }
        #app { width: 100%; height: 100%; position: relative; }
        
        .slide { position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; visibility: hidden; transition: opacity 0.8s ease-in-out; z-index: 1; background: black; display: flex; justify-content: center; align-items: center; }
        .slide.active { opacity: 1; visibility: visible; z-index: 5; }
        
        /* IMAGEM DE FUNDO (Com Zoom) */
        .news-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; filter: brightness(0.35); transform: scale(1); animation: zoomEffect 20s linear forwards; }
        
        /* FUNDO DE COR SÓLIDA/GRADIENTE (Sem Zoom) */
        .solid-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; }
        
        @keyframes zoomEffect { to { transform: scale(1.15); } }
        
        .news-container { position: absolute; bottom: 0; left: 0; width: 100%; padding: 5% 6%; z-index: 10; background: linear-gradient(to top, rgba(0,0,0,0.95) 10%, rgba(0,0,0,0.5) 60%, transparent 100%); }
        
        .badge { color: white; padding: 6px 14px; font-weight: 700; text-transform: uppercase; border-radius: 4px; display: inline-block; margin-bottom: 15px; font-size: clamp(12px, 1.8vw, 24px); box-shadow: 0 2px 10px rgba(0,0,0,0.5); }
        .title { font-size: clamp(24px, 4.5vw, 65px); font-weight: 800; line-height: 1.15; margin-bottom: 20px; text-shadow: 2px 2px 10px rgba(0,0,0,0.8); display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
        .desc { font-size: clamp(16px, 2.5vw, 36px); color: #e0e0e0; border-left: 5px solid #E50914; padding-left: 20px; line-height: 1.4; max-width: 90%; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
        
        .ad-media { width: 100%; height: 100%; object-fit: contain; background-color: #000; }
        .slide[data-type="ad"] img, .slide[data-type="ad"] video { filter: none !important; animation: none !important; }
        
        .header { position: absolute; top: 0; left: 0; width: 100%; padding: 3vh 5vw; display: flex; justify-content: space-between; align-items: center; z-index: 20; background: linear-gradient(to bottom, rgba(0,0,0,0.8), transparent); }
        .tv-name { font-size: clamp(18px, 3vh, 40px); font-weight: bold; text-transform: uppercase; letter-spacing: 1px; text-shadow: 1px 1px 5px rgba(0,0,0,0.8); }
        .tv-clock { font-size: clamp(22px, 3.5vh, 45px); font-weight: bold; text-shadow: 1px 1px 5px rgba(0,0,0,0.8); }
        
        @media (max-aspect-ratio: 1/1) { .news-container { padding-bottom: 10vh; } .title { -webkit-line-clamp: 4; } .desc { display: none; } }
    </style>
</head>
<body>
    <div class="header">
        <div class="tv-name"><?php echo $tituloTv; ?></div>
        <div class="tv-clock" id="relogio">--:--</div>
    </div>
    <div id="app">
        <?php foreach ($playlist as $i => $item): ?>
            <div class="slide" data-type="<?php echo $item['type']; ?>" data-media="<?php echo isset($item['media']) ? $item['media'] : ''; ?>" data-dur="<?php echo $item['dur']; ?>">
                
                <?php if ($item['type'] == 'news'): ?>
                    
                    <?php if (!empty($item['content']['img'])): ?>
                        <!-- Tem imagem no RSS -->
                        <img src="<?php echo $item['content']['img']; ?>" class="news-bg" onerror="this.style.display='none'; this.parentElement.querySelector('.solid-bg').style.display='block';">
                        <!-- Backup caso a imagem do RSS esteja quebrada -->
                        <div class="solid-bg" style="background: <?php echo $bgGradients[array_rand($bgGradients)]; ?>; display:none;"></div>
                    <?php else: ?>
                        <!-- Não tem imagem, usa o gradiente sorteado -->
                        <div class="solid-bg" style="background: <?php echo $item['content']['bg_gradient']; ?>;"></div>
                    <?php endif; ?>

                    <div class="news-container">
                        <span class="badge" style="background-color: <?php echo isset($item['content']['color']) ? $item['content']['color'] : '#E50914'; ?>;">
                            <?php echo $item['content']['src']; ?>
                        </span>
                        <h1 class="title"><?php echo $item['content']['tit']; ?></h1>
                        <p class="desc" style="border-left-color: <?php echo isset($item['content']['color']) ? $item['content']['color'] : '#E50914'; ?>;">
                            <?php echo $item['content']['desc']; ?>
                        </p>
                    </div>

                <?php elseif ($item['type'] == 'ad'): ?>
                    <?php if ($item['media'] == 'video'): ?>
                        <video src="<?php echo $item['url']; ?>" class="ad-media" muted playsinline></video>
                    <?php else: ?>
                        <img src="<?php echo $item['url']; ?>" class="ad-media">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        let currentVersion = <?php echo $lastUpdate; ?>;
        const slides = document.querySelectorAll('.slide');
        let curr = 0; let timer;

        function run() {
            if(!slides.length) return;
            const s = slides[curr];
            const type = s.dataset.type;
            const media = s.dataset.media;
            const duration = parseInt(s.dataset.dur) || 10000;

            if (type === 'news' || (type === 'ad' && media === 'imagem')) {
                timer = setTimeout(next, duration);
            } 
            else if (type === 'ad' && media === 'video') {
                const vid = s.querySelector('video');
                if(vid) {
                    vid.currentTime = 0;
                    vid.play().catch(e => { next(); });
                    vid.onended = next;
                } else { timer = setTimeout(next, 5000); }
            }
        }

        function next() {
            clearTimeout(timer);
            const prevVid = slides[curr].querySelector('video'); if(prevVid) prevVid.pause();
            slides[curr].classList.remove('active');
            curr = (curr + 1) % slides.length;
            slides[curr].classList.add('active');
            run();
        }

        setInterval(() => { document.getElementById('relogio').innerText = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}); }, 1000);
        
        setInterval(() => {
            fetch('config.json?nocache=' + Date.now())
                .then(response => response.json())
                .then(data => {
                    if (data.last_update && data.last_update > currentVersion) {
                        window.location.reload();
                    }
                })
                .catch(err => console.log("Check update error"));
        }, 5000);

        setTimeout(() => window.location.reload(), 1800000);
        if(slides.length > 0) { slides[0].classList.add('active'); run(); }
    </script>
</body>
</html>