<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TV Corporativa</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700;900&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #E50914; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #000; font-family: 'Roboto', sans-serif; overflow: hidden; width: 100vw; height: 100vh; color: white; cursor: none; }
        
        #tv-container { width: 100%; height: 100%; position: relative; background: #000; }
        
        /* HEADER */
        .header { position: absolute; top: 0; left: 0; width: 100%; height: 14vh; padding: 0 4vw; display: flex; justify-content: space-between; align-items: center; z-index: 50; background: linear-gradient(to bottom, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0) 100%); }
        .brand h1 { font-size: 2.5vh; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; color: rgba(255,255,255,0.95); text-shadow: 2px 2px 4px rgba(0,0,0,0.8); }
        .brand p { font-size: 1.8vh; font-weight: 400; color: #ddd; }
        .clock { font-size: 5vh; font-weight: 700; text-shadow: 2px 2px 5px rgba(0,0,0,0.5); font-variant-numeric: tabular-nums; }

        /* SLIDE TRANSITIONS */
        .slide { position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; visibility: hidden; transition: opacity 1s ease; z-index: 10; background: #000; }
        .slide.active { opacity: 1; visibility: visible; z-index: 20; }
        
        /* MEDIA */
        .bg-img, .bg-video { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; background: #111; }
        .slide[data-type="noticia"] .bg-img { filter: brightness(0.4); transform: scale(1); }
        .slide.active[data-type="noticia"] .bg-img.zoom { animation: zoomSlow 20s linear forwards; }
        .solid-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; }

        /* CONTENT */
        .news-content { position: absolute; bottom: 0; left: 0; width: 100%; padding: 5vh 5vw 8vh 5vw; z-index: 30; background: linear-gradient(to top, rgba(0,0,0,1) 10%, transparent 100%); }
        .source-badge { display: inline-block; padding: 0.8vh 2vh; border-radius: 4px; font-weight: 900; text-transform: uppercase; letter-spacing: 1px; font-size: 1.8vh; margin-bottom: 2vh; box-shadow: 0 4px 10px rgba(0,0,0,0.5); text-shadow: 1px 1px 2px rgba(0,0,0,0.5); }
        .news-title { font-size: 5.5vh; line-height: 1.1; font-weight: 900; margin-bottom: 2vh; text-shadow: 2px 2px 10px rgba(0,0,0,0.9); display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
        .news-desc { font-size: 2.8vh; line-height: 1.4; font-weight: 300; color: #eee; border-left: 5px solid var(--primary); padding-left: 2vh; max-width: 90%; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; text-shadow: 1px 1px 3px rgba(0,0,0,0.8); }

        .slide[data-type="ad"] .bg-img, .slide[data-type="ad"] .bg-video { object-fit: contain; }
        @keyframes zoomSlow { from { transform: scale(1); } to { transform: scale(1.1); } }
    </style>
</head>
<body>
    <div class="header">
        <div class="brand">
            <h1 id="tv-title">TV CORPORATIVA</h1>
            <p id="data-display">Carregando...</p>
        </div>
        <div class="clock" id="relogio">00:00</div>
    </div>
    
    <div id="tv-container">
        <!-- Slides inseridos via JS -->
    </div>

    <script>
        let playlistData = [];
        let currentIndex = 0;
        let slideTimer = null;
        let configVersion = 0;

        // --- 1. RELÓGIO ---
        function updateClock() {
            const now = new Date();
            document.getElementById('relogio').textContent = now.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
            document.getElementById('data-display').textContent = now.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
        }
        setInterval(updateClock, 1000); updateClock();

        // --- 2. CARREGAR DADOS (API) ---
        async function fetchPlaylist(initial = false) {
            try {
                const res = await fetch('api.php?t=' + Date.now());
                const data = await res.json();
                
                if (data.error) return console.error(data.error);

                // Se houver atualização de config, atualiza título e playlist
                if (initial || data.last_update > configVersion) {
                    console.log("Atualizando playlist...");
                    configVersion = data.last_update;
                    document.getElementById('tv-title').textContent = data.titulo_tv;
                    playlistData = data.playlist;
                    
                    if (initial) {
                        renderSlide(0); // Começa
                    }
                }
            } catch (e) {
                console.error("Erro conexão API", e);
            }
        }

        // --- 3. RENDERIZADOR ---
        function renderSlide(index) {
            if (playlistData.length === 0) return;
            const container = document.getElementById('tv-container');
            const item = playlistData[index];
            
            // Cria HTML do slide
            const div = document.createElement('div');
            div.className = 'slide active'; // Já nasce ativo
            div.dataset.type = item.tipo;
            div.dataset.media = item.midia_tipo || '';

            let html = '';
            
            if (item.tipo === 'noticia') {
                const imgTag = item.conteudo.imagem ? `<img src="${item.conteudo.imagem}" class="bg-img zoom" onerror="this.style.display='none'">` : '';
                const opacity = item.conteudo.imagem ? '0.6' : '1';
                
                html = `
                    ${imgTag}
                    <div class="solid-bg" style="background: ${item.conteudo.bg}; opacity:${opacity}"></div>
                    <div class="news-content">
                        <span class="source-badge" style="background: ${item.conteudo.cor}">${item.conteudo.fonte}</span>
                        <h2 class="news-title">${item.conteudo.titulo}</h2>
                        <p class="news-desc" style="border-color: ${item.conteudo.cor}">${item.conteudo.descricao}</p>
                    </div>`;
            } else {
                // AD
                if (item.midia_tipo === 'video') {
                    html = `<video src="${item.url}" class="bg-video" muted playsinline autoplay></video>`;
                } else {
                    html = `<img src="${item.url}" class="bg-img">`;
                }
            }
            
            div.innerHTML = html;

            // Remove slide anterior (limpeza)
            container.innerHTML = ''; 
            container.appendChild(div);

            // Gerencia tempo
            let duration = parseInt(item.duracao) || 10000;
            
            if (item.tipo === 'ad' && item.midia_tipo === 'video') {
                const video = div.querySelector('video');
                video.addEventListener('ended', nextSlide);
                video.addEventListener('error', () => setTimeout(nextSlide, 2000));
                // Fallback de segurança para vídeo travado
                slideTimer = setTimeout(nextSlide, duration + 5000); 
            } else {
                slideTimer = setTimeout(nextSlide, duration);
            }
        }

        function nextSlide() {
            clearTimeout(slideTimer);
            currentIndex++;
            
            // Se chegou ao fim, checa atualizações e reseta
            if (currentIndex >= playlistData.length) {
                currentIndex = 0;
                fetchPlaylist(false).then(() => {
                    renderSlide(0);
                });
            } else {
                renderSlide(currentIndex);
            }
        }

        // Inicialização
        fetchPlaylist(true);

    </script>
</body>
</html>