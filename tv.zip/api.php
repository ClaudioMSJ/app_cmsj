<?php
// ARQUIVO: api.php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
ini_set('display_errors', 0);
error_reporting(E_ALL);
date_default_timezone_set('America/Sao_Paulo');

// --- DEFINIÇÃO DE PASTAS ---
$pastaData = 'data/';
$pastaUploads = 'uploads/';

// Cria a pasta de dados se não existir
if (!is_dir($pastaData)) {
    mkdir($pastaData, 0777, true);
    // Segurança: Cria .htaccess para bloquear acesso direto aos JSONs via navegador
    file_put_contents($pastaData . '.htaccess', "Deny from all");
}

$configFile = $pastaData . 'config.json';
$cacheFile  = $pastaData . 'cache_news.json';

// 1. Carregar Configurações
if (!file_exists($configFile)) {
    echo json_encode(['error' => 'Sistema não configurado']);
    exit;
}
$config = json_decode(file_get_contents($configFile), true);

// Parâmetros
$rssSources    = $config['rss_sources'] ?? [];
$ads           = $config['ads'] ?? [];
$freqAds       = $config['frequencia_ads'] ?? 2;
$maxNoticias   = $config['max_noticias_total'] ?? 20;
$tempoSlide    = ($config['tempo_slide'] ?? 15) * 1000;
$tituloTv      = $config['titulo_tv'] ?? "TV Corporativa";

// --- FUNÇÕES ---
function obterCorFonte($nome) {
    $nome = mb_strtolower($nome, 'UTF-8');
    $cores = [
        'g1' => '#C4170C', 'globo' => '#C4170C', 'uol' => '#F9A01B', 
        'cnn' => '#CC0000', 'bbc' => '#BB1919', 'folha' => '#004D8C',
        'estadao' => '#193975', 'tecmundo' => '#0587D6', 'espn' => '#CD112C'
    ];
    foreach ($cores as $key => $cor) {
        if (stripos($nome, $key) !== false) return $cor;
    }
    return '#E50914';
}

function fetchUrl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

// --- LÓGICA DE CACHE ---
$noticias = [];
$usarCache = false;
$cacheExpirado = true;

// Verifica se cache existe e é recente (menos de 10 min)
if (file_exists($cacheFile)) {
    if ((time() - filemtime($cacheFile)) < 600) {
        $cacheExpirado = false;
    }
    $dadosCache = json_decode(file_get_contents($cacheFile), true);
    if (!empty($dadosCache)) {
        $noticias = $dadosCache;
        $usarCache = true;
    }
}

// Se cache expirou ou não existe, baixa RSS
if ($cacheExpirado && !empty($rssSources)) {
    $novasNoticias = [];
    libxml_use_internal_errors(true);
    
    foreach ($rssSources as $url) {
        if(empty(trim($url))) continue;
        $xmlContent = fetchUrl($url);
        
        if ($xmlContent) {
            $xml = simplexml_load_string($xmlContent, 'SimpleXMLElement', LIBXML_NOCDATA);
            if ($xml) {
                $fonteTitle = mb_substr((string)$xml->channel->title, 0, 30);
                $corBadge = obterCorFonte($fonteTitle);
                $namespaces = $xml->getNamespaces(true);
                
                $count = 0;
                foreach ($xml->channel->item as $item) {
                    if ($count >= 4) break;
                    
                    $tit = trim((string)$item->title);
                    $descRaw = (string)$item->description;
                    $todoConteudo = $descRaw . ' ' . (isset($namespaces['content']) ? (string)$item->children($namespaces['content'])->encoded : '');

                    // Busca Imagem
                    $img = '';
                    $melhorLargura = 0;

                    // 1. Media RSS
                    if (isset($namespaces['media'])) {
                        $media = $item->children($namespaces['media']);
                        if (isset($media->content)) {
                            foreach($media->content as $c) {
                                $attr = $c->attributes();
                                $tipo = (string)$attr->type;
                                $urlM = (string)$attr->url;
                                $w = isset($attr->width) ? (int)$attr->width : 0;
                                
                                if (strpos($tipo, 'image') !== false || preg_match('/\.(jpg|png|webp)/i', $urlM)) {
                                    if ($w >= $melhorLargura) { $melhorLargura = $w; $img = $urlM; }
                                    elseif ($melhorLargura == 0) { $img = $urlM; }
                                }
                            }
                        }
                        if (empty($img) && isset($media->thumbnail)) {
                            $attr = $media->thumbnail->attributes();
                            $img = (string)$attr->url;
                        }
                    }
                    
                    // 2. Enclosure
                    if (empty($img) && isset($item->enclosure)) {
                        $attr = $item->enclosure->attributes();
                        if (strpos((string)$attr->type, 'image') !== false) $img = (string)$attr->url;
                    }

                    // 3. Regex
                    if (empty($img)) {
                        preg_match_all('/(https?:\/\/[^\s"\'<>]+\.(jpg|jpeg|png|webp))/i', $todoConteudo, $matches);
                        if (!empty($matches[0])) {
                            foreach ($matches[0] as $possibleImg) {
                                if (strpos($possibleImg, 'pixel') === false && strpos($possibleImg, 'spacer') === false) {
                                    $img = $possibleImg;
                                    break;
                                }
                            }
                        }
                    }

                    // Limpeza Texto
                    $desc = strip_tags($descRaw);
                    $desc = preg_replace('/\s+/', ' ', $desc);
                    if (mb_strlen($desc) > 180) $desc = mb_substr($desc, 0, 180) . '...';

                    if (empty($desc) && isset($namespaces['content'])) {
                         $desc = strip_tags((string)$item->children($namespaces['content'])->encoded);
                         if (mb_strlen($desc) > 180) $desc = mb_substr($desc, 0, 180) . '...';
                    }

                    $novasNoticias[] = [
                        'tipo' => 'noticia',
                        'duracao' => $tempoSlide,
                        'conteudo' => [
                            'titulo' => $tit,
                            'descricao' => $desc,
                            'imagem' => $img,
                            'fonte' => $fonteTitle,
                            'cor' => $corBadge
                        ]
                    ];
                    $count++;
                }
            }
        }
    }

    if (!empty($novasNoticias)) {
        file_put_contents($cacheFile, json_encode($novasNoticias));
        $noticias = $novasNoticias;
    }
}

// --- MONTAGEM DA PLAYLIST FINAL ---
shuffle($noticias);
$noticias = array_slice($noticias, 0, $maxNoticias);

$gradientes = [
    'linear-gradient(135deg, #111, #2c3e50)',
    'linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d)',
    'linear-gradient(135deg, #000428, #004e92)',
    'linear-gradient(135deg, #232526, #414345)'
];

$playlist = [];
$totalAds = count($ads);
$adIndex = 0;
$newsCounter = 0;
usort($ads, function($a, $b) { return ($a['ordem'] ?? 99) <=> ($b['ordem'] ?? 99); });

if ($totalAds > 0 && !empty($noticias)) {
    foreach ($noticias as $news) {
        $news['conteudo']['bg'] = $gradientes[array_rand($gradientes)];
        $playlist[] = $news;
        $newsCounter++;
        
        if ($newsCounter % $freqAds == 0) {
            $adAtual = $ads[$adIndex % $totalAds];
            $caminhoAd = $pastaUploads . $adAtual['arquivo'];
            if (file_exists($caminhoAd)) {
                $playlist[] = [
                    'tipo' => 'ad',
                    'midia_tipo' => $adAtual['tipo'],
                    'duracao' => ($adAtual['duracao'] > 0) ? $adAtual['duracao'] * 1000 : 10000,
                    'url' => $caminhoAd . '?v=' . time()
                ];
                $adIndex++;
            }
        }
    }
} elseif ($totalAds > 0) {
    foreach ($ads as $ad) {
        $playlist[] = [
            'tipo' => 'ad',
            'midia_tipo' => $ad['tipo'],
            'duracao' => ($ad['duracao'] > 0) ? $ad['duracao'] * 1000 : 10000,
            'url' => $pastaUploads . $ad['arquivo']
        ];
    }
} else {
    foreach($noticias as $k => $v) $noticias[$k]['conteudo']['bg'] = $gradientes[array_rand($gradientes)];
    $playlist = $noticias;
}

if (empty($playlist)) {
    $playlist[] = [
        'tipo' => 'noticia', 
        'duracao' => 5000, 
        'conteudo' => [
            'titulo' => 'Carregando...', 
            'descricao' => 'Aguardando atualização.', 
            'imagem' => '', 
            'fonte' => 'Sistema', 
            'cor' => '#333', 
            'bg' => '#222'
        ]
    ];
}

echo json_encode([
    'titulo_tv' => $tituloTv,
    'playlist' => $playlist,
    'last_update' => $config['last_update'] ?? 0
]);