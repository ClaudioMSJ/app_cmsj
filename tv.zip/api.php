<?php
// ARQUIVO: api.php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
ini_set('display_errors', 0);
error_reporting(E_ALL);
date_default_timezone_set('America/Sao_Paulo');

$pastaData = 'data/';
$pastaads = 'ads/';
$configFile = $pastaData . 'config.json';
$cacheFile  = $pastaData . 'cache_news.json';

// Configuração padrão de fallback
$configDefault = [
    'last_update' => 0,
    'titulo_tv' => 'TV Corporativa',
    'ads' => [],
    'rss_sources' => [],
    'tempo_slide' => 15,
    'max_noticias_total' => 60,
    'frequencia_ads' => 3
];

$config = file_exists($configFile) ? json_decode(file_get_contents($configFile), true) : $configDefault;
if (!$config) $config = $configDefault;

// Rota Leve (Check Version)
if (isset($_GET['check_version'])) {
    echo json_encode(['last_update' => $config['last_update'] ?? 0]);
    exit;
}

// --- ROTA PESADA (PLAYLIST) ---

// Cores das fontes
function obterCorFonte($nome) {
    $n = mb_strtolower($nome);
    if(strpos($n,'g1')!==false || strpos($n,'globo')!==false) return '#C4170C';
    if(strpos($n,'uol')!==false) return '#F9A01B';
    if(strpos($n,'cnn')!==false) return '#CC0000';
    if(strpos($n,'tecmundo')!==false) return '#0587D6';
    if(strpos($n,'espn')!==false) return '#CD112C';
    return '#E50914';
}

$noticias = [];
$usarCache = false;

// Tenta usar cache (10 min)
if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 600) {
    $dadosCache = json_decode(file_get_contents($cacheFile), true);
    if (is_array($dadosCache) && !empty($dadosCache)) {
        $noticias = $dadosCache;
        $usarCache = true;
    }
}

// Se cache falhar/expirar, baixa RSS
if (!$usarCache && !empty($config['rss_sources'])) {
    $novasNoticias = [];
    $mh = curl_multi_init();
    $curl_arr = [];

    foreach ($config['rss_sources'] as $i => $url) {
        if(empty(trim($url))) continue;
        $curl_arr[$i] = curl_init($url);
        curl_setopt($curl_arr[$i], CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl_arr[$i], CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl_arr[$i], CURLOPT_TIMEOUT, 8);
        curl_setopt($curl_arr[$i], CURLOPT_USERAGENT, 'TVCorporativa/1.0');
        curl_setopt($curl_arr[$i], CURLOPT_SSL_VERIFYPEER, false);
        curl_multi_add_handle($mh, $curl_arr[$i]);
    }

    $running = null;
    do { curl_multi_exec($mh, $running); } while ($running);

    libxml_use_internal_errors(true);
    
    foreach ($curl_arr as $ch) {
        $xmlContent = curl_multi_getcontent($ch);
        if ($xmlContent) {
            $xml = simplexml_load_string($xmlContent, 'SimpleXMLElement', LIBXML_NOCDATA);
            if ($xml && isset($xml->channel->item)) {
                $fonteTitle = mb_substr((string)$xml->channel->title, 0, 30);
                $corBadge = obterCorFonte($fonteTitle);
                $ns = $xml->getNamespaces(true);
                
                $count = 0;
                foreach ($xml->channel->item as $item) {
                    if ($count++ >= 5) break; 
                    
                    $tit = trim((string)$item->title);
                    $descRaw = (string)$item->description;
                    
                    // Extração de Imagem
                    $img = '';
                    if (isset($ns['media'])) {
                        $media = $item->children($ns['media']);
                        if($media->content) {
                            foreach($media->content as $c) {
                                $attr = $c->attributes();
                                if (strpos((string)$attr->type, 'image') !== false) { $img = (string)$attr->url; break; }
                            }
                        }
                    }
                    if (!$img && isset($item->enclosure)) {
                        $attr = $item->enclosure->attributes();
                        if (strpos((string)$attr->type, 'image') !== false) $img = (string)$attr->url;
                    }
                    if (!$img) {
                        preg_match_all('/(https?:\/\/[^\s"\'<>]+\.(?:jpg|jpeg|png|webp))/i', $descRaw, $matches);
                        foreach($matches[0] as $urlImg) {
                            if(strpos($urlImg, 'pixel')===false && strpos($urlImg,'spacer')===false) { $img = $urlImg; break; }
                        }
                    }

                    $desc = strip_tags($descRaw);
                    $desc = mb_strlen($desc) > 160 ? mb_substr($desc, 0, 160) . '...' : $desc;

                    if(!empty($tit)) {
                        $novasNoticias[] = [
                            'tipo' => 'noticia',
                            'duracao' => ($config['tempo_slide'] ?? 15) * 1000,
                            'conteudo' => [
                                'titulo'=>$tit, 'descricao'=>$desc, 'imagem'=>$img, 
                                'fonte'=>$fonteTitle, 'cor'=>$corBadge
                            ]
                        ];
                    }
                }
            }
        }
        curl_multi_remove_handle($mh, $ch);
    }
    curl_multi_close($mh);

    if (!empty($novasNoticias)) {
        $noticias = $novasNoticias;
        file_put_contents($cacheFile, json_encode($noticias));
    }
}

// Montagem Playlist
shuffle($noticias);
$noticias = array_slice($noticias, 0, ($config['max_noticias_total'] ?? 60));

$playlist = [];
$ads = $config['ads'] ?? [];
$totalAds = count($ads);
$freqAds = max(1, intval($config['frequencia_ads'] ?? 3));

// Ordenação dos Ads
usort($ads, function($a, $b) { return ($a['ordem'] ?? 0) <=> ($b['ordem'] ?? 0); });

$adIndex = 0;
$newsCounter = 0;
$gradientes = ['linear-gradient(135deg,#111,#2c3e50)', 'linear-gradient(135deg,#0f2027,#203a43,#2c5364)', 'linear-gradient(135deg,#141e30,#243b55)'];

if (empty($noticias) && empty($ads)) {
    $playlist[] = [
        'tipo'=>'noticia', 
        'duracao'=>10000, 
        'conteudo'=>['titulo'=>'Bem-vindo', 'descricao'=>'Acesse o painel para configurar.', 'imagem'=>'', 'fonte'=>'Sistema', 'cor'=>'#333', 'bg'=>'#000']
    ];
} else {
    // Intercala notícias e anúncios
    foreach ($noticias as $news) {
        $news['conteudo']['bg'] = $gradientes[array_rand($gradientes)];
        $playlist[] = $news;
        $newsCounter++;
        
        if ($totalAds > 0 && ($newsCounter % $freqAds == 0)) {
            $ad = $ads[$adIndex % $totalAds];
            $arquivo = $pastaads . $ad['arquivo'];
            if (file_exists($arquivo)) {
                $playlist[] = [
                    'tipo' => 'ad',
                    'midia_tipo' => $ad['tipo'],
                    'duracao' => ($ad['tipo']=='video' ? 0 : ($ad['duracao']*1000)),
                    'url' => $arquivo . '?v=' . time()
                ];
                $adIndex++;
            }
        }
    }
    // Se não tiver notícias, roda só ads
    if(empty($noticias) && $totalAds > 0) {
        foreach($ads as $ad) {
             $playlist[] = [
                 'tipo'=>'ad', 
                 'midia_tipo'=>$ad['tipo'], 
                 'duracao'=>($ad['tipo']=='video'?0:($ad['duracao']*1000)), 
                 'url'=>$pastaads.$ad['arquivo']
             ];
        }
    }
}

echo json_encode([
    'titulo_tv' => $config['titulo_tv'] ?? 'TV Corporativa',
    'playlist' => $playlist,
    'last_update' => $config['last_update'] ?? 0
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>